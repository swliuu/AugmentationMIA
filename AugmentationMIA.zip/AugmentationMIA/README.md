# TrajectoryMIA

Code for CCS 2022 "Membership Inference Attacks by Exploiting Loss Trajectory".

## Environmment

 - Linux with Python 3.8

 - PyTorch>=1.10.0

## Usage

### :tennis: First step: Train target model and shadow model

- Target model
```
python main.py --mode target
```
- Shadow model
```
python main.py --mode shadow
```
The shadow model is trained to mimic the behavior of the target model.

### :guitar: Second Step: Distill target model and shadow model

- Distill target model
```
python main.py --mode distill_target
```
- Distill shadow model
```
python main.py --mode distill_shadow
```
Here although we can get the loss trajectory from the original training processs of the shadow model, we still distill it in order to better align with the scenario for the target model. More explanations can be found in our paper.

### :dog: Third step: Prepare the dataset for attack model

- Get attack model training data
```
python main.py --action 1 --mode shadow --mia_type build-dataset
```
- Get attack model testing data
```
python main.py --action 1 --mode target --mia_type build-dataset
```
From this step, we obtain the loss trajectory for each data sample.

### :watermelon: Fourth step: Train and test attack model

```
python main.py --action 1 --mia_type black-box
```
The loss trajectory will be the input to train and test the attack model.

## Note

- The trained models and generated data are saved to './networks/{seed}/{mode}/{data}_{model}'.
- The code above uses the default settings (ResNet-56 trained on CIFAR-100 with 100 epochs), you can change them with the corresponding arguments.

## Citation

For technical details and full experimental results, please refer to [the paper](https://dl.acm.org/doi/abs/10.1145/3548606.3560684).

```
@inproceedings{LZBZ22,
author = {Yiyong Liu and Zhengyu Zhao and Michael Backes and Yang Zhang},
title = {{Membership Inference Attacks by Exploiting Loss Trajectory}},
booktitle = {{ACM SIGSAC Conference on Computer and Communications Security (CCS)}},
pages = {2085-2098},
publisher = {ACM},
year = {2022}
}
```

## Contact

Feel free to contact yiyong.liu@cispa.de if you have any question on the codes. Enjoy!
