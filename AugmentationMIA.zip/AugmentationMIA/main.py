import os
import argparse
import utils
import normal
import MIA
import UMIA
import architectures
import numpy as np
import torch
import torch.nn as nn
import torch.utils.data as Data
import torch.nn.functional as F
from statistics import mean
from util_calibration import ts_calibrate, ets_calibrate, mir_calibrate, irova_calibrate
import test
cos = nn.CosineSimilarity(dim=-1, eps=1e-6)
dis_kd = nn.KLDivLoss(reduction='mean')
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

def train_networks(args):
    device = utils.get_pytorch_device()
    utils.create_path('./outputs')
    if 'distill' in args.mode:
        model_path_tar = 'networks/{}/{}'.format(0, args.mode.split('_')[-1])
        utils.create_path(model_path_tar)
        model_path_dis = 'networks/{}/{}'.format(args.seed, args.mode)
        utils.create_path(model_path_dis)
    else:
        model_path_tar = 'networks/{}/{}'.format(args.seed, args.mode)
        utils.create_path(model_path_tar)
        model_path_dis = None

    utils.set_logger('outputs/train_models'.format(args.seed))
    normal.train_models(args, model_path_tar, model_path_dis, device)

def membership_inference_attack(args):
    print(f'--------------{args.mia_type}-------------')

    device = utils.get_pytorch_device()

    if args.mia_type == 'build-dataset':
        models_path = 'networks/{}'.format(0)
        MIA.build_trajectory_membership_dataset(args, models_path, device)

    if args.mia_type == 'black-box':
        trained_models_path = 'networks/{}'.format(args.seed)
        MIA.trajectory_black_box_membership_inference_attack(args, trained_models_path, device)

def get_cos(loader_1,loader_2,device,MODEL,flag):
    attack_x = []
    for (data_batch_1,data_batch_2) in zip(loader_1,loader_2):

        if flag:
            (data_1, target_1, ori_idx_1) = data_batch_1
            (data_2, target_2, ori_idx_2) = data_batch_2
        else:
            (data_1, target_1) = data_batch_1 # 自定义的dataloader只有数据和标签两部分
            (data_2, target_2) = data_batch_2

        data_1, target_1 = data_1.to(device), target_1.to(device)
        data_2, target_2 = data_2.to(device), target_2.to(device)

        if flag:
            batch_logit_target_1 = MODEL(data_1)
            batch_logit_target_2 = MODEL(data_2)
        else:
            batch_logit_target_1 = torch.tensor(data_1)
            batch_logit_target_2 = torch.tensor(data_2)


        cos_ts = cos(batch_logit_target_1, batch_logit_target_2) #torch.Size([200])
        batch_cos = cos_ts.cpu().detach().numpy() #batch_cos.shape(200,)
        batch_cos = batch_cos.reshape(-1,1) #batch_cos.shape(200,1)

        attack_x.append(batch_cos)

    return attack_x


def get_logit(data_loader,device,MODEL):
    logit_cali = []
    label = []
    thresh = 0.5
    j = 0
    max = []

    for i, (data, target, ori_idx) in enumerate(data_loader):
        data = data.to(device)
        batch_logit_target = MODEL(data)
        batch_logit_target = batch_logit_target.cpu().detach().numpy()  # 将tensor转化为numpy
        target = target.cpu().detach().numpy()
        batch_new = []
        batch_label = []
        for (s,l) in zip(batch_logit_target,target):  # 对batch中的每一个向量进行处理
            s_max = np.argmax(s)  # 获得置信度向量最大值的下标
            s_cali = s
            s_cali = UMIA.softmax_t(s_cali, 100) # 对向量进行数据校准
            s_row_max = s_cali.max(axis=-1) # 获取校准后向量的最大值
            max.append(s_row_max)
            if s_row_max > thresh:
                s = s_cali # 如果向量满足校准条件则进行校准
                j = j + 1
            batch_new.append(s)
            batch_label.append(l)

        logit_cali.append(batch_new)
        label.append(batch_label)


    print(j)
    print(mean(max))
    logit_cali = np.array(logit_cali)
    label = np.array(label)
    logit_cali = torch.tensor(logit_cali)
    label = torch.tensor(label)

    torch_dataset = Data.TensorDataset(logit_cali, label)  # 对给定的 tensor 数据，将他们包装成 dataset
    loader = Data.DataLoader(
        # 从数据库中每次抽出batch size个样本
        dataset=torch_dataset,  # torch TensorDataset format
        batch_size=200,  # mini batch size
        shuffle=False,  # 要不要打乱数据 (打乱比较好)
        num_workers=1,  # 多线程来读数据
    )

    return loader


def membership_umia_cos(args):
    if args.model == 'vgg':
        model_name = '{}_vgg16bn'.format(args.data)
    elif args.model == 'mobilenet':
        model_name = '{}_mobilenet'.format(args.data)
    elif args.model == 'resnet':
        model_name = '{}_resnet56'.format(args.data)
    elif args.model == 'wideresnet':
        model_name = '{}_wideresnet'.format(args.data)

    device = utils.get_pytorch_device()
    models_path = 'networks/{}'.format(1)

    cnn_model, cnn_params = normal.load_model(args, models_path + '/target', model_name, epoch=args.epochs)

    MODEL = cnn_model.to(device)

    #load_path = './networks/1/target/mnist_resnet/parameters' # mnist处理
    #model = test.ResNet(test.ResidualBlock, [2, 2, 2]) # mnist处理
    #model.load_state_dict(torch.load(load_path), strict=False) # mnist处理
    #MODEL = model.to(device) # mnist处理


    dataset = utils.get_dataset(cnn_params['task'], mode=args.mode, aug=False, batch_size=1)
    aug_data = True # aug_data为True表示attack model的输入数据要进行数据增强
    aug_test = True

    if aug_data:
        print('load Flip target_dataset ... ')
        train_loader_flip = dataset.target_train_aug_loader2
        train_loader_crop = dataset.target_train_aug_loader3
        train_loader_vertical_flip = dataset.target_train_aug_loader4
        train_loader_bright = dataset.target_train_aug_loader5

        #进行数据校准
        train_loader_flip = get_logit(train_loader_flip, device, MODEL)
        train_loader_crop = get_logit(train_loader_crop, device, MODEL)
        train_loader_vertical_flip = get_logit(train_loader_vertical_flip, device, MODEL)
        train_loader_bright = get_logit(train_loader_bright, device, MODEL)

        if aug_test:
            test_loader_flip = dataset.target_test_aug_loader2
            test_loader_crop = dataset.target_test_aug_loader3
            test_loader_vertical_flip = dataset.target_test_aug_loader4
            test_loader_bright = dataset.target_test_aug_loader5

            # 进行数据校准
            test_loader_flip = get_logit(test_loader_flip, device, MODEL)
            test_loader_crop = get_logit(test_loader_crop, device, MODEL)
            test_loader_vertical_flip = get_logit(test_loader_vertical_flip, device, MODEL)
            test_loader_bright = get_logit(test_loader_bright, device, MODEL)


        else:
            test_loader = dataset.target_test_loader


    else:  #获取target model的traing data和test data
        print('load original target_dataset ... ')
        train_loader = dataset.target_train_loader
        test_loader = dataset.target_test_loader

    MODEL.eval()


    if aug_data:
        attack_train_1 = get_cos(train_loader_flip, train_loader_crop, device, MODEL, False)
        attack_train_2 = get_cos(train_loader_flip, train_loader_vertical_flip, device, MODEL, False)
        attack_train_3 = get_cos(train_loader_flip, train_loader_bright, device, MODEL, False)
        attack_train_4 = get_cos(train_loader_crop, train_loader_vertical_flip, device, MODEL, False)
        attack_train_5 = get_cos(train_loader_crop, train_loader_bright, device, MODEL, False)
        attack_train_6 = get_cos(train_loader_vertical_flip, train_loader_bright, device, MODEL, False)

        attack_train_1 = torch.tensor(attack_train_1)  # torch.Size([50, 200, 1])
        attack_train_2 = torch.tensor(attack_train_2)
        attack_train_3 = torch.tensor(attack_train_3)
        attack_train_4 = torch.tensor(attack_train_4)
        attack_train_5 = torch.tensor(attack_train_5)
        attack_train_6 = torch.tensor(attack_train_6)

        attack_train = torch.cat([attack_train_1, attack_train_2], dim=2)
        attack_train = torch.cat([attack_train, attack_train_3], dim=2)
        attack_train = torch.cat([attack_train, attack_train_4], dim=2)
        attack_train = torch.cat([attack_train, attack_train_5], dim=2)
        attack_train = torch.cat([attack_train, attack_train_6], dim=2)

        if aug_test:
            attack_test_1 = get_cos(test_loader_flip,test_loader_crop, device, MODEL, False)
            attack_test_2 = get_cos(test_loader_flip, test_loader_vertical_flip, device, MODEL, False)
            attack_test_3 = get_cos(test_loader_flip, test_loader_bright, device, MODEL, False)
            attack_test_4 = get_cos(test_loader_crop, test_loader_vertical_flip, device, MODEL, False)
            attack_test_5 = get_cos(test_loader_crop, test_loader_bright, device, MODEL, False)
            attack_test_6 = get_cos(test_loader_vertical_flip, test_loader_bright, device, MODEL, False)

            attack_test_1 = torch.tensor(attack_test_1)
            attack_test_2 = torch.tensor(attack_test_2)
            attack_test_3 = torch.tensor(attack_test_3)
            attack_test_4 = torch.tensor(attack_test_4)
            attack_test_5 = torch.tensor(attack_test_5)
            attack_test_6 = torch.tensor(attack_test_6)

            attack_test = torch.cat([attack_test_1, attack_test_2], dim=2)
            attack_test = torch.cat([attack_test, attack_test_3], dim=2)
            attack_test = torch.cat([attack_test, attack_test_4], dim=2)
            attack_test = torch.cat([attack_test, attack_test_5], dim=2)
            attack_test = torch.cat([attack_test, attack_test_6], dim=2)

        else:
            attack_test_tensor = test_loader # 直接将test data构造为inference data,但要保证维度与attack_train一致
            attack_test = []

            for i, (data,target,ori_idx) in enumerate(attack_test_tensor):
                data = data.to(device)
                batch_logit_target = MODEL(data)
                batch_logit_target = batch_logit_target.cpu().detach().numpy()  # 将tensor转化为numpy
                batch_new = []
                for s in batch_logit_target: # 对batch中的每一个向量进行处理
                    s_new = sorted(s, reverse=True)[0:6]
                    batch_new.append(s_new)
                attack_test.append(batch_new)

            attack_test = np.array(attack_test) # attack_test.shape(50, 200, 6)
            attack_test = UMIA.softmax_t(attack_test, 100)
            attack_test = torch.tensor(attack_test) # torch.Size([50, 200, 6])


        for loader_idx, dataset_cos in enumerate([attack_train, attack_test]):
            for i, batch_cos in enumerate(dataset_cos):
                member = np.repeat(np.array(int(1 - loader_idx)), batch_cos.shape[0], 0)
                attack_x = batch_cos if loader_idx == 0 and i == 0 else np.concatenate((attack_x, batch_cos), axis=0)
                attack_y = member if loader_idx == 0 and i == 0 else np.concatenate((attack_y, member), axis=0)



    else:
        attack_train = train_loader
        attack_test = test_loader

        for loader_idx, dataloader in enumerate([attack_train, attack_test]):
            for i, (data,target,idx) in enumerate(dataloader):
                data = data.to(device)
                batch_logit_target = MODEL(data) #得到data经过taeget model的置信度向量

                #batch_logit_target = batch_logit_target.cpu().detach().numpy() #将tensor转化为numpy
                batch_logit_target = np.array([batch_logit_target_i.cpu().detach().numpy() for batch_logit_target_i in batch_logit_target])

                member = np.repeat(np.array(int(1 - loader_idx)), batch_logit_target.shape[0], 0)
                attack_x = batch_logit_target if loader_idx == 0 and i == 0 else np.concatenate((attack_x, batch_logit_target), axis=0)
                attack_y = member if loader_idx == 0 and i == 0 else np.concatenate((attack_y, member), axis=0)


    print(f'------------Loading umia attack dataset successfully!---------')
    data = {
        'attack_x': attack_x,
        'attack_y': attack_y,
        'nb_classes': dataset.num_classes
    }
    np.save(f'networks/umia/attack_data', data)

    UMIA.trainAttackModel(attack_x, attack_y, clip_k=3, rescale_t=100)




if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='TrajectoryMIA')
    parser.add_argument('--action', type=int, default=0, help=[0, 1, 2, 3])
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--mode', type=str, default='shadow', help=['target', 'shadow', 'distill_target', 'distill_shadow'])
    parser.add_argument('--model', type=str, default='resnet', help=['resnet', 'mobilenet', 'vgg', 'wideresnet'])
    parser.add_argument('--data', type=str, default='cifar10', help=['cinic10', 'cifar10', 'cifar100', 'gtsrb', 'mnist'])
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--model_distill', type=str, default='resnet', help=['resnet', 'mobilenet', 'vgg', 'wideresnet'])
    parser.add_argument('--epochs_distill', type=int, default=100)
    parser.add_argument('--mia_type', type=str,default='black-box', help=['build-dataset', 'black-box'])

    args = parser.parse_args()
    utils.set_random_seeds(args.seed)
    print('random seed:{}'.format(args.seed))

    if args.action == 0:
        train_networks(args)

    elif args.action == 1:
        membership_inference_attack(args)

    #加载之前保存的inference data进行成员推理攻击a
    elif args.action == 2:
        data = np.load('./networks/umia/CIFAR10/cifar10_wideresnet_cos/attack_data.npy',allow_pickle=True)
        attack_x = data.item()['attack_x']
        attack_y = data.item()['attack_y']
        UMIA.trainAttackModel(attack_x, attack_y, clip_k=3, rescale_t=100)

    #构造inference data并执行成员推理攻击
    elif args.action == 3:
        membership_umia_cos(args)












