import os
import argparse
import utils
import normal
import MIA
import UMIA
import time
import architectures
import numpy as np
import torch
import torch.nn as nn
import torch.utils.data as Data
import torch.nn.functional as F
import matplotlib.pyplot as plt
import pickle
from statistics import mean
from util_calibration import ts_calibrate, ets_calibrate, mir_calibrate, irova_calibrate
import test
import util_calibration

cos = nn.CosineSimilarity(dim=-1, eps=1e-6)
dis_kd = nn.KLDivLoss(reduction='mean')
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'


def train_networks(args):
    device = utils.get_pytorch_device()
    utils.create_path('./outputs')
    if 'distill' in args.mode:
        model_path_tar = 'networks/{}/{}'.format(1, args.mode.split('_')[-1])
        utils.create_path(model_path_tar)
        model_path_dis = 'networks/{}/{}'.format(args.seed, args.mode)
        utils.create_path(model_path_dis)
    else:
        model_path_tar = 'networks/{}/{}'.format(args.seed, args.mode)
        utils.create_path(model_path_tar)
        model_path_dis = None

    utils.set_logger('outputs/train_models'.format(args.seed))
    normal.train_models(args, model_path_tar, model_path_dis, device)


# 此函数用于获取数据集经过target model得到的置信度向量
def get_output(args):
    if args.model == 'vgg':
        model_name = '{}_vgg16bn'.format(args.data)
    elif args.model == 'mobilenet':
        model_name = '{}_mobilenet'.format(args.data)
    elif args.model == 'resnet':
        model_name = '{}_resnet56'.format(args.data)
    elif args.model == 'wideresnet':
        model_name = '{}_wideresnet'.format(args.data)

    device = utils.get_pytorch_device()
    models_path = 'networks/1/target'
    cnn_model, cnn_params = normal.load_model(args, models_path, model_name, epoch=args.epochs)
    MODEL = cnn_model.to(device)

    dataset = utils.get_dataset(cnn_params['task'], mode=args.mode, aug=False, batch_size=1)

    train_loader_0 = dataset.target_train_loader
    train_loader_1 = dataset.target_train_aug_loader1
    train_loader_2 = dataset.target_train_aug_loader2
    train_loader_3 = dataset.target_train_aug_loader3
    train_loader_4 = dataset.target_train_aug_loader4
    train_loader_5 = dataset.target_train_aug_loader5


    test_loader_0 = dataset.target_test_loader
    test_loader_1 = dataset.target_test_aug_loader1
    test_loader_2 = dataset.target_test_aug_loader2
    test_loader_3 = dataset.target_test_aug_loader3
    test_loader_4 = dataset.target_test_aug_loader4
    test_loader_5 = dataset.target_test_aug_loader5

    with torch.no_grad():
        for i, (data, target, ori_idx) in enumerate(train_loader_5):
            data = data.cpu().detach().numpy()
            data = np.squeeze(data)
            data = np.transpose(data, (1, 2, 0))  # 把channel那一维放到最后,(3,32,32)--->(32,32,3)
            # 反Normalize操作
            data = (data * [0.229, 0.224, 0.225] + [0.485, 0.456, 0.406]) * 255
            plt.imshow(data.astype('uint8'))
            plt.axis('off')
            dir = "./overview/cifar_100/color_3/" + str(i) + ".png"
            plt.savefig(dir, dpi=1000, bbox_inches='tight', pad_inches=0)
            plt.show()


    MODEL.eval()
    prediction = []
    output = []
    attack_x = []
    sum = 0
    with torch.no_grad():
        for loader_idx, dataloader in enumerate([train_loader_5, test_loader_5]):# 读取dataloader中的每一个batch
            data = data.to(device)
            target = target.to(device)
            batch_output = MODEL(data)  # 得到data经过target model的置信度向量
            #batch_output = batch_output.cpu().detach().numpy()

            # 返回预测标签 + 预测置信度向量
            output.append(batch_output)
            predict_label = torch.argmax(batch_output, dim=1)
            predict_label = predict_label.float()
            predict_label = predict_label.cpu().detach().numpy().item()
            prediction.append(predict_label)


            '''
            attack_x.append(batch_output)
            member = np.repeat(np.array(int(1 - loader_idx)), batch_output.shape[0], 0)
            attack_y = member if loader_idx == 0 and i == 0 else np.concatenate((attack_y, member), axis=0)
            '''

            '''
            #返回预测标签 + 预测是否正确（1/0）
            for (s, l) in zip(batch_output, target):  # 对batch中的每一个向量进行处理
                s_max = np.argmax(s)  # 获得置信度向量最大值的下标
                if s_max == l:
                    attack_x.append(1)
                else:
                    attack_x.append(0)
            member = np.repeat(np.array(int(1 - loader_idx)), batch_output.shape[0], 0)
            attack_y = member if loader_idx == 0 and i == 0 else np.concatenate((attack_y, member), axis=0)
            '''





            '''
            # Confidence(Yeom et al.)
            predict_score, _ = torch.max(batch_output, dim=1)
            predict_score = predict_score.cpu().detach().numpy().item()
            prediction.append(predict_score)
            member = np.repeat(np.array(int(1 - loader_idx)), batch_output.shape[0], 0)
            true_label = member if loader_idx == 0 and i == 0 else np.concatenate((true_label, member), axis=0)
            '''

            '''
            # 返回真实标签 + 预测最大概率值
            CE = F.cross_entropy(batch_output, target).cpu().detach().numpy().item()
            prediction.append(CE)
            member = np.repeat(np.array(int(loader_idx)), batch_output.shape[0], 0)
            true_label = member if loader_idx == 0 and i == 0 else np.concatenate((true_label, member), axis=0)
            '''


        print(len(prediction))
        print(len(output))

        data = {
            'prediction': prediction,
            'output': output
        }
        dir_path = './attack_data/ratio/' + model_name + '/non_member'
        print(dir_path)
        if os.path.exists(dir_path):
            pass
        else:
            os.mkdir(dir_path)
        np.save(dir_path + '/attack_data_5.npy', data)


def aug_choose(args):
    if args.model == 'vgg':
        model_name = '{}_vgg16bn'.format(args.data)
    elif args.model == 'mobilenet':
        model_name = '{}_mobilenet'.format(args.data)
    elif args.model == 'resnet':
        model_name = '{}_resnet56'.format(args.data)
    elif args.model == 'wideresnet':
        model_name = '{}_wideresnet_da5'.format(args.data)

    device = utils.get_pytorch_device()
    models_path = 'networks/{}'.format(1)
    cnn_model, cnn_params = normal.load_model(args, models_path + '/target_da', model_name, epoch=args.epochs)
    MODEL = cnn_model.to(device)

    dataset = utils.get_dataset(cnn_params['task'], mode=args.mode, aug=False, batch_size=1)
    train_loader_pad = dataset.target_train_aug_loader1
    train_loader_flip = dataset.target_train_aug_loader2
    train_loader_crop = dataset.target_train_aug_loader3
    train_loader_vertical_flip = dataset.target_train_aug_loader4
    train_loader_bright = dataset.target_train_aug_loader5
    train_loader_rotation = dataset.target_train_aug_loader6
    train_loader_affine = dataset.target_train_aug_loader7

    test_loader_pad = dataset.target_test_aug_loader1
    test_loader_flip = dataset.target_test_aug_loader2
    test_loader_crop = dataset.target_test_aug_loader3
    test_loader_vertical_flip = dataset.target_test_aug_loader4
    test_loader_bright = dataset.target_test_aug_loader5
    test_loader_rotation = dataset.target_test_aug_loader6
    test_loader_affine = dataset.target_test_aug_loader7

    idx1_tr = get_idx(train_loader_pad, device, MODEL)
    idx1_te = get_idx(test_loader_pad, device, MODEL)
    print('Pad',':',len(idx1_tr+idx1_te))

    idx2_tr = get_idx(train_loader_flip, device, MODEL)
    idx2_te = get_idx(test_loader_flip, device, MODEL)
    print('Flip', ':', len(idx2_tr+idx2_te))

    idx3_tr = get_idx(train_loader_crop, device, MODEL)
    idx3_te = get_idx(test_loader_crop, device, MODEL)
    print('Crop', ':', len(idx3_tr + idx3_te))

    idx4_tr = get_idx(train_loader_vertical_flip, device, MODEL)
    idx4_te = get_idx(test_loader_vertical_flip, device, MODEL)
    print('Vertical_Flip', ':', len(idx4_tr + idx4_te))

    idx5_tr = get_idx(train_loader_bright, device, MODEL)
    idx5_te = get_idx(test_loader_bright, device, MODEL)
    print('ColorJitter', ':', len(idx5_tr + idx5_te))

    idx6_tr = get_idx(train_loader_rotation, device, MODEL)
    idx6_te = get_idx(test_loader_rotation, device, MODEL)
    print('Rotation', ':', len(idx6_tr + idx6_te))

    idx7_tr = get_idx(train_loader_affine, device, MODEL)
    idx7_te = get_idx(test_loader_affine, device, MODEL)
    print('Affine', ':', len(idx7_tr + idx7_te))


def membership_inference_attack(args):
    print(f'--------------{args.mia_type}-------------')

    device = utils.get_pytorch_device()

    if args.mia_type == 'build-dataset':
        models_path = 'networks/{}'.format(1)
        MIA.build_trajectory_membership_dataset(args, models_path, device)

    if args.mia_type == 'black-box':
        trained_models_path = 'networks/{}'.format(args.seed)
        MIA.trajectory_black_box_membership_inference_attack(args, trained_models_path, device)


def get_cos(loader_1, loader_2, device, MODEL, flag):
    attack_x = []
    for (data_batch_1, data_batch_2) in zip(loader_1, loader_2):

        if flag:
            (data_1, target_1, ori_idx_1) = data_batch_1
            (data_2, target_2, ori_idx_2) = data_batch_2
        else:
            data_1 = data_batch_1[0]  # 自定义的dataloader只有数据和标签两部分
            target_1 = data_batch_1[1]
            data_2 = data_batch_2[0]
            target_2 = data_batch_2[1]

        data_1, target_1 = data_1.to(device), target_1.to(device)
        data_2, target_2 = data_2.to(device), target_2.to(device)

        if flag:
            batch_logit_target_1 = MODEL(data_1)
            batch_logit_target_2 = MODEL(data_2)
        else:
            batch_logit_target_1 = torch.tensor(data_1)
            batch_logit_target_2 = torch.tensor(data_2)

        cos_ts = cos(batch_logit_target_1, batch_logit_target_2)  # torch.Size([200])
        batch_cos = cos_ts.cpu().detach().numpy()  # batch_cos.shape(200,)
        batch_cos = batch_cos.reshape(-1, 1)  # batch_cos.shape(200,1)

        attack_x.append(batch_cos)

    return attack_x


def merge_idx(idx1, idx2, idx3, idx4, idx5):
    merge_idx3 = []
    merge_idx4 = []
    merge_idx5 = []

    dict = {}
    merge_list = idx1 + idx2 + idx3 + idx4 + idx5
    merge_np = np.array(merge_list)
    key = np.unique(merge_np)
    for i in key:
        dict[i] = np.sum(merge_np == i)

    for key, value in dict.items():
        if value == 3:
            merge_idx3.append(key)
        if value == 4:
            merge_idx4.append(key)
        if value == 5:
            merge_idx5.append(key)

    return merge_idx3, merge_idx4, merge_idx5


def get_idx(data_loader, device, MODEL):
    MODEL.eval()
    index = []  # 存储满足筛选条件的数据的下标
    j = 0

    with torch.no_grad():
        for i, (data, target, ori_idx) in enumerate(data_loader):
            data = data.to(device)
            batch_logit_target = MODEL(data)
            batch_logit_target = batch_logit_target.cpu().detach().numpy()  # 将tensor转化为numpy
            target = target.cpu().detach().numpy()
            for (s, l) in zip(batch_logit_target, target):  # 对batch中的每一个向量进行处理
                s_max = np.argmax(s)  # 获得置信度向量最大值的下标
                if s_max == l:
                    index.append(j)
                j = j + 1
    return index


def get_cali_loader(data_loader, device, MODEL, index):
    MODEL.eval()
    logit = []
    label = []

    with torch.no_grad():
        for i, (data, target, ori_idx) in enumerate(data_loader):
            data = data.to(device)
            batch_logit_target = MODEL(data)
            batch_logit_target = batch_logit_target.cpu().detach().numpy()  # 将tensor转化为numpy
            target = target.cpu().detach().numpy()
            for (s, l) in zip(batch_logit_target, target):  # 对batch中的每一个向量进行处理
                logit.append(s)
                label.append(l)

    logit = np.array(logit)
    label = np.array(label)

    for i in range(len(index)):
        #logit[i] = UMIA.softmax_t(np.log(logit[i]), 100)
        logit[i] = UMIA.softmax_t(logit[i], 100)  # 对满足筛选条件的向量进行数据校准


    logit = torch.tensor(logit)
    label = torch.tensor(label)

    torch_dataset = Data.TensorDataset(logit, label)  # 对给定的 tensor 数据，将他们包装成 dataset
    loader = Data.DataLoader(
        # 从数据库中每次抽出batch size个样本
        dataset=torch_dataset,  # torch TensorDataset format
        batch_size=200,  # mini batch size
        shuffle=False,  # 要不要打乱数据 (打乱比较好)
        num_workers=1,  # 多线程来读数据
    )

    return loader


def CE_cos():
    data_0 = np.load('./networks/umia/CE/attack_data_0.npy', allow_pickle=True)
    CE_x_0 = data_0.item()['attack_x']
    attack_y = data_0.item()['attack_y']

    data_1 = np.load('./networks/umia/CE/attack_data_1.npy', allow_pickle=True)
    CE_x_1 = data_1.item()['attack_x']

    data_2 = np.load('./networks/umia/CE/attack_data_2.npy', allow_pickle=True)
    CE_x_2 = data_2.item()['attack_x']

    data_3 = np.load('./networks/umia/CE/attack_data_3.npy', allow_pickle=True)
    CE_x_3 = data_3.item()['attack_x']

    data_4 = np.load('./networks/umia/CE/attack_data_4.npy', allow_pickle=True)
    CE_x_4 = data_4.item()['attack_x']

    data_5 = np.load('./networks/umia/CE/attack_data_5.npy', allow_pickle=True)
    CE_x_5 = data_5.item()['attack_x']

    tensor_0 = torch.tensor(CE_x_0)
    tensor_1 = torch.tensor(CE_x_1)
    tensor_2 = torch.tensor(CE_x_2)
    tensor_3 = torch.tensor(CE_x_3)
    tensor_4 = torch.tensor(CE_x_4)
    tensor_5 = torch.tensor(CE_x_5)

    cos_1 = cos(tensor_0, tensor_1)
    cos_2 = cos(tensor_0, tensor_2)
    cos_3 = cos(tensor_0, tensor_3)
    cos_4 = cos(tensor_0, tensor_4)
    cos_5 = cos(tensor_0, tensor_5)

    cos_1 = cos_1.view(-1, 1)
    cos_2 = cos_2.view(-1, 1)
    cos_3 = cos_3.view(-1, 1)
    cos_4 = cos_4.view(-1, 1)
    cos_5 = cos_5.view(-1, 1)

    attack_x = torch.cat([cos_1, cos_2], dim=1)
    attack_x = torch.cat([attack_x, cos_3], dim=1)
    attack_x = torch.cat([attack_x, cos_4], dim=1)
    attack_x = torch.cat([attack_x, cos_5], dim=1)

    attack_x = attack_x.cpu().detach().numpy()

    print(f'------------Loading umia attack dataset successfully!---------')
    data = {
        'attack_x': attack_x,
        'attack_y': attack_y,
    }
    np.save(f'networks/umia/attack_data', data)

    UMIA.trainAttackModel(attack_x, attack_y, clip_k=5, rescale_t=100)


def CE_cluster(args):
    if args.model == 'vgg':
        model_name = '{}_vgg16bn'.format(args.data)
    elif args.model == 'mobilenet':
        model_name = '{}_mobilenet'.format(args.data)
    elif args.model == 'resnet':
        model_name = '{}_resnet56'.format(args.data)
    elif args.model == 'wideresnet':
        model_name = '{}_wideresnet'.format(args.data)

    device = utils.get_pytorch_device()
    models_path = 'networks/{}'.format(1)
    cnn_model, cnn_params = normal.load_model(args, models_path + '/target', model_name, epoch=args.epochs)
    MODEL = cnn_model.to(device)

    dataset = utils.get_dataset(cnn_params['task'], mode=args.mode, aug=False, batch_size=1)

    train_loader_5 = dataset.target_train_aug_loader5
    test_loader_5 = dataset.target_test_aug_loader5

    MODEL.eval()
    attack_x = []
    attack_y = []
    with torch.no_grad():
        for loader_idx, dataloader in enumerate([train_loader_5, test_loader_5]):
            for i, (data, target, idx) in enumerate(dataloader): # 读取dataloader中的每一个batch
                data = data.to(device)
                target = target.to(device)
                batch_output = MODEL(data)  # 得到data经过taeget model的置信度向量
                predict_label = torch.argmax(batch_output,dim=1)
                predict_label = predict_label.cpu().detach().numpy().item()

                CE = []
                for i in range(10):
                    if i != predict_label:
                        label_i = np.array([i])
                        label_i = torch.tensor(label_i)
                        label_i = label_i.to(device)
                        CE_i = F.cross_entropy(batch_output, label_i.long()).cpu().detach().numpy()
                        CE.append(CE_i)

                CE = np.array(CE)
                #ACE = np.mean(CE)
                attack_x.append(CE)
                member = np.repeat(np.array(int(1 - loader_idx)), batch_output.shape[0], 0)
                attack_y = member if loader_idx == 0 and i == 0 else np.concatenate((attack_y, member), axis=0)


    attack_x = np.array(attack_x)

    print(f'------------Loading umia attack dataset successfully!---------')
    data = {
        'attack_x': attack_x,
        'attack_y': attack_y,
        'nb_classes': dataset.num_classes
    }
    np.save(f'networks/umia/attack_data', data)

    UMIA.trainAttackModel(attack_x, attack_y, clip_k=9, rescale_t=100)


def membership_umia_cos(args):
    if args.model == 'vgg':
        model_name = '{}_vgg16bn'.format(args.data)
    elif args.model == 'mobilenet':
        model_name = '{}_mobilenet'.format(args.data)
    elif args.model == 'resnet':
        model_name = '{}_resnet56'.format(args.data)
    elif args.model == 'wideresnet':
        model_name = '{}_wideresnet'.format(args.data)

    device = utils.get_pytorch_device()
    models_path = 'networks/{}'.format(1)
    cnn_model, cnn_params = normal.load_model(args, models_path + '/target', model_name, epoch=args.epochs)
    MODEL = cnn_model.to(device)

    # load_path = './networks/1/target/mnist_resnet/parameters' # mnist处理
    # model = test.ResNet(test.ResidualBlock, [2, 2, 2]) # mnist处理
    # model.load_state_dict(torch.load(load_path), strict=False) # mnist处理
    # MODEL = model.to(device) # mnist处理

    dataset = utils.get_dataset(cnn_params['task'], mode=args.mode, aug=False, batch_size=1)

    aug_data = True  # aug_data为True表示attack model的输入数据要进行数据增强
    aug_test = True

    train_loader_ori = dataset.target_train_loader
    test_loader_ori = dataset.target_test_loader
    index_train = get_idx(train_loader_ori, device, MODEL)
    index_test = get_idx(test_loader_ori, device, MODEL)


    if aug_data:
        print('load Flip target_dataset ... ')
        train_loader_1 = dataset.target_train_aug_loader1
        train_loader_2 = dataset.target_train_aug_loader2
        train_loader_3 = dataset.target_train_aug_loader3
        train_loader_4 = dataset.target_train_aug_loader4
        train_loader_5 = dataset.target_train_aug_loader5



        # 进行数据校准
        # index_train_flip = get_idx(train_loader_flip, device, MODEL)
        # index_train_crop = get_idx(train_loader_crop, device, MODEL)
        # index_train_vertical_flip = get_idx(train_loader_vertical_flip, device, MODEL)
        # index_train_bright = get_idx(train_loader_bright, device, MODEL)
        # idx_train3, idx_train4, idx_train5 = merge_idx(index_train, index_train_flip, index_train_crop, index_train_vertical_flip, index_train_bright)
        # train_loader_flip = get_cali_loader(train_loader_flip, device, MODEL, idx_train5)
        # train_loader_crop = get_cali_loader(train_loader_crop, device, MODEL, idx_train5)
        # train_loader_vertical_flip = get_cali_loader(train_loader_vertical_flip, device, MODEL, idx_train5)
        # train_loader_bright = get_cali_loader(train_loader_bright, device, MODEL, idx_train5)

        if aug_test:
            test_loader_1 = dataset.target_test_aug_loader1
            test_loader_2 = dataset.target_test_aug_loader2
            test_loader_3 = dataset.target_test_aug_loader3
            test_loader_4 = dataset.target_test_aug_loader4
            test_loader_5 = dataset.target_test_aug_loader5

            # 进行数据校准
            # index_test_flip = get_idx(test_loader_flip, device, MODEL)
            # index_test_crop = get_idx(test_loader_crop, device, MODEL)
            # index_test_vertical_flip = get_idx(test_loader_vertical_flip, device, MODEL)
            # index_test_bright = get_idx(test_loader_bright, device, MODEL)
            # idx_test3, idx_test4, idx_test5 = merge_idx(index_test, index_test_flip, index_test_crop, index_test_vertical_flip, index_test_bright)
            # test_loader_flip = get_cali_loader(test_loader_flip, device, MODEL, idx_test5)
            # test_loader_crop = get_cali_loader(test_loader_crop, device, MODEL, idx_test5)
            # test_loader_vertical_flip = get_cali_loader(test_loader_vertical_flip, device, MODEL, idx_test5)
            # test_loader_bright = get_cali_loader(test_loader_bright, device, MODEL, idx_test5)


        else:
            test_loader = test_loader_ori


    else:  # 获取target model的traing data和test data
        print('load original target_dataset ... ')
        train_loader = train_loader_ori
        test_loader = test_loader_ori

    MODEL.eval()

    if aug_data:
        attack_train_1 = get_cos(train_loader_1, train_loader_2, device, MODEL, True)
        attack_train_2 = get_cos(train_loader_1, train_loader_3, device, MODEL, True)
        attack_train_3 = get_cos(train_loader_1, train_loader_4, device, MODEL, True)
        attack_train_4 = get_cos(train_loader_2, train_loader_3, device, MODEL, True)
        attack_train_5 = get_cos(train_loader_2, train_loader_4, device, MODEL, True)
        attack_train_6 = get_cos(train_loader_3, train_loader_4, device, MODEL, True)

        attack_train_1 = torch.tensor(attack_train_1)  # torch.Size([50, 200, 1])
        attack_train_2 = torch.tensor(attack_train_2)
        attack_train_3 = torch.tensor(attack_train_3)
        attack_train_4 = torch.tensor(attack_train_4)
        attack_train_5 = torch.tensor(attack_train_5)
        attack_train_6 = torch.tensor(attack_train_6)

        attack_train = torch.cat([attack_train_1, attack_train_2], dim=2)
        attack_train = torch.cat([attack_train, attack_train_3], dim=2)
        attack_train = torch.cat([attack_train, attack_train_4], dim=2)
        attack_train = torch.cat([attack_train, attack_train_5], dim=2)
        attack_train = torch.cat([attack_train, attack_train_6], dim=2)

        if aug_test:
            attack_test_1 = get_cos(test_loader_1, test_loader_2, device, MODEL, True)
            attack_test_2 = get_cos(test_loader_1, test_loader_3, device, MODEL, True)
            attack_test_3 = get_cos(test_loader_1, test_loader_4, device, MODEL, True)
            attack_test_4 = get_cos(test_loader_2, test_loader_3, device, MODEL, True)
            attack_test_5 = get_cos(test_loader_2, test_loader_4, device, MODEL, True)
            attack_test_6 = get_cos(test_loader_3, test_loader_4, device, MODEL, True)

            attack_test_1 = torch.tensor(attack_test_1)
            attack_test_2 = torch.tensor(attack_test_2)
            attack_test_3 = torch.tensor(attack_test_3)
            attack_test_4 = torch.tensor(attack_test_4)
            attack_test_5 = torch.tensor(attack_test_5)
            attack_test_6 = torch.tensor(attack_test_6)

            attack_test = torch.cat([attack_test_1, attack_test_2], dim=2)
            attack_test = torch.cat([attack_test, attack_test_3], dim=2)
            attack_test = torch.cat([attack_test, attack_test_4], dim=2)
            attack_test = torch.cat([attack_test, attack_test_5], dim=2)
            attack_test = torch.cat([attack_test, attack_test_6], dim=2)

        else:
            attack_test_tensor = test_loader  # 直接将test data构造为inference data,但要保证维度与attack_train一致
            attack_test = []

            for i, (data, target, ori_idx) in enumerate(attack_test_tensor):
                data = data.to(device)
                batch_logit_target = MODEL(data)
                batch_logit_target = batch_logit_target.cpu().detach().numpy()  # 将tensor转化为numpy
                batch_new = []
                for s in batch_logit_target:  # 对batch中的每一个向量进行处理
                    s_new = sorted(s, reverse=True)[0:6]
                    batch_new.append(s_new)
                attack_test.append(batch_new)

            attack_test = np.array(attack_test)  # attack_test.shape(50, 200, 6)
            attack_test = UMIA.softmax_t(attack_test, 100)
            attack_test = torch.tensor(attack_test)  # torch.Size([50, 200, 6])

        for loader_idx, dataset_cos in enumerate([attack_train, attack_test]):
            for i, batch_cos in enumerate(dataset_cos):
                member = np.repeat(np.array(int(1 - loader_idx)), batch_cos.shape[0], 0)
                attack_x = batch_cos if loader_idx == 0 and i == 0 else np.concatenate((attack_x, batch_cos), axis=0)
                attack_y = member if loader_idx == 0 and i == 0 else np.concatenate((attack_y, member), axis=0)



    else:
        attack_train = train_loader
        attack_test = test_loader

        for loader_idx, dataloader in enumerate([attack_train, attack_test]):
            for i, (data, target, idx) in enumerate(dataloader):
                data = data.to(device)
                batch_logit_target = MODEL(data)  # 得到data经过taeget model的置信度向量

                # batch_logit_target = batch_logit_target.cpu().detach().numpy() #将tensor转化为numpy
                batch_logit_target = np.array(
                    [batch_logit_target_i.cpu().detach().numpy() for batch_logit_target_i in batch_logit_target])

                member = np.repeat(np.array(int(1 - loader_idx)), batch_logit_target.shape[0], 0)
                attack_x = batch_logit_target if loader_idx == 0 and i == 0 else np.concatenate(
                    (attack_x, batch_logit_target), axis=0)
                attack_y = member if loader_idx == 0 and i == 0 else np.concatenate((attack_y, member), axis=0)

    print(f'------------Loading umia attack dataset successfully!---------')
    data = {
        'attack_x': attack_x,
        'attack_y': attack_y,
        'nb_classes': dataset.num_classes
    }
    np.save(f'networks/umia/attack_data', data)

    UMIA.trainAttackModel(attack_x, attack_y, clip_k=3, rescale_t=100)


def get_calibrated_losses(attack_x, private_model, attack_model, dataloader, device):
    """
    return calibrated losses
    """

    with torch.no_grad():
        for i, (data, target, idx) in enumerate(dataloader):
            data = data.to(device)
            target = target.to(device)

            output = private_model(data)
            loss = F.cross_entropy(output, target)

            attack_output = attack_model(data)
            attack_loss = F.cross_entropy(attack_output, target)

            losses = attack_loss - loss
            losses = losses.cpu().detach().numpy()
            attack_x.append(losses)


def cali_MIA(args):
    if args.model == 'vgg':
        model_name = '{}_vgg16bn'.format(args.data)
    elif args.model == 'mobilenet':
        model_name = '{}_mobilenet'.format(args.data)
    elif args.model == 'resnet':
        model_name = '{}_resnet56'.format(args.data)
    elif args.model == 'wideresnet':
        model_name = '{}_wideresnet'.format(args.data)

    device = utils.get_pytorch_device()

    target_path = 'networks/1/target'
    attack_path = 'networks/1/shadow'
    t_model, t_params = normal.load_model(args, target_path, model_name, epoch=args.epochs)
    a_model, a_params = normal.load_model(args, attack_path, model_name, epoch=args.epochs)

    dataset = utils.get_dataset(t_params['task'], mode=args.mode, aug=False, batch_size=1)

    T_MODEL = t_model.to(device)
    A_MODEL = a_model.to(device)

    # 加载目标模型的训练集和测试集
    trainset = dataset.target_train_loader
    testset = dataset.target_test_loader

    # 计算矫正后的损失值
    T_MODEL.eval()
    A_MODEL.eval()

    for i in range(10000):
        member = np.repeat(np.array(1), 1, 0)
        attack_y = member if i == 0 else np.concatenate((attack_y, member), axis=0)

    for i in range(10000):
        member = np.repeat(np.array(0), 1, 0)
        attack_y = member if i == -1 else np.concatenate((attack_y, member), axis=0)

    attack_x = []
    get_calibrated_losses(attack_x, T_MODEL, A_MODEL, trainset, device)
    get_calibrated_losses(attack_x, T_MODEL, A_MODEL, testset, device)

    print(len(attack_x))
    print(len(attack_y))


    data = {
        'prediction': attack_x,
        'true_label': attack_y
    }
    dir_path = 'attack_data/roc/cali_loss/' + model_name
    print(dir_path)
    if os.path.exists(dir_path):
        pass
    else:
        os.mkdir(dir_path)
    np.save(dir_path + '/attack_data.npy', data)



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='TrajectoryMIA')
    parser.add_argument('--action', type=int, default=0, help=[0, 1, 2, 3, 4, 5, 6, 7, 8])
    parser.add_argument('--seed', type=int, default=4)
    parser.add_argument('--mode', type=str, default='shadow', help=['target', 'shadow', 'distill_target', 'distill_shadow'])
    parser.add_argument('--model', type=str, default='resnet', help=['resnet', 'mobilenet', 'vgg', 'wideresnet'])
    parser.add_argument('--data', type=str, default='cifar10', help=['cinic10', 'cifar10', 'cifar100', 'gtsrb', 'mnist'])
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--model_distill', type=str, default='wideresnet', help=['resnet', 'mobilenet', 'vgg', 'wideresnet'])
    parser.add_argument('--epochs_distill', type=int, default=100)
    parser.add_argument('--mia_type', type=str, default='black-box', help=['build-dataset', 'black-box'])

    args = parser.parse_args()
    utils.set_random_seeds(args.seed)
    print('random seed:{}'.format(args.seed))

    if args.action == 0:
        start = time.time()
        train_networks(args)
        end = time.time()
        print("程序用时：", end - start, "秒")

    elif args.action == 1:
        membership_inference_attack(args)

    # 加载之前保存的inference data进行成员推理攻击
    elif args.action == 2:
        # data = np.load('./networks/umia/attack_data.npy', allow_pickle=True)
        # attack_x = data.item()['attack_x']
        # attack_y = data.item()['attack_y']
        data = np.load('./networks/umia/attack_data.npy', allow_pickle=True)
        attack_x = data.item()['attack_x']
        attack_y = data.item()['attack_y']
        UMIA.trainAttackModel(attack_x, attack_y, clip_k=9, rescale_t=100)

    # 构造inference data并执行成员推理攻击
    elif args.action == 3:
        membership_umia_cos(args)

    # 选择合适的数据增强方式
    elif args.action == 4:
        aug_choose(args)

    elif args.action == 5:
        CE_cluster(args)

    elif args.action == 6:
        CE_cos()

    # 获得 target model 的 output + prediction
    elif args.action == 7:
        get_output(args)

    # 对比实验4
    elif args.action == 8:
        cali_MIA(args)

