import torch
import torch.nn as nn
import numpy as np
import utils
import normal
import argparse
import time
import pickle
import torch.nn.functional as F
import torch.optim as optim
from sklearn.metrics import f1_score, roc_auc_score
from sklearn.metrics import classification_report, accuracy_score
import matplotlib.pyplot as plt


# attack model的架构
class PartialAttackModel(nn.Module):
    def __init__(self, class_num):
        super(PartialAttackModel, self).__init__()
        self.Output_Component = nn.Sequential(
            # nn.Dropout(p=0.2),
            nn.Linear(class_num, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
        )

        self.Prediction_Component = nn.Sequential(
            # nn.Dropout(p=0.2),
            nn.Linear(6, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
        )

        self.Encoder_Component = nn.Sequential(
            # nn.Dropout(p=0.2),
            nn.Linear(128, 256),
            nn.ReLU(),
            # nn.Dropout(p=0.2),
            nn.Linear(256, 128),
            nn.ReLU(),
            # nn.Dropout(p=0.2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 2),
        )


    def forward(self, output, prediction):
        Output_Component_result = self.Output_Component(output)
        Prediction_Component_result = self.Prediction_Component(prediction)
        final_inputs = torch.cat((Output_Component_result, Prediction_Component_result), 1)
        final_result = self.Encoder_Component(final_inputs)

        return final_result


def get_pre(cnn_params, MODEL, device):
    dataset = utils.get_dataset(cnn_params['task'], mode=args.mode, aug=False, batch_size=1)
    train_loader_0 = dataset.target_train_loader
    test_loader_0 = dataset.target_test_loader

    MODEL.eval()
    prediction = []
    with torch.no_grad():
        for loader_idx, dataloader in enumerate([train_loader_0, test_loader_0]):
            for i, (data, target, idx) in enumerate(dataloader):  # 读取dataloader中的每一个batch
                data = data.to(device)
                batch_output = MODEL(data)  # 得到data经过taeget model的置信度向量
                predict_label = torch.argmax(batch_output, dim=1)
                predict_label = predict_label.float()
                #predict_label = predict_label.cpu().detach().numpy().item()
                prediction.append(predict_label)

    return prediction


def prepare_dataset():
    ATTACK_SETS = './attack_data/time/10000_10000/'

    data = np.load('./networks/umia/cifar10/cifar10_resnet56/attack_data.npy', allow_pickle=True)
    members = data.item()['attack_y']

    data_0 = np.load('./attack_data/output/Resnet/CINIC10/attack_data_5.npy', allow_pickle=True)
    output = data_0.item()['output']
    prediction = data_0.item()['prediction']
    # print(len(output))

    data_1 = np.load('./attack_data/ratio/cinic10_resnet56/non_member/attack_data_5.npy', allow_pickle=True)
    non_output = data_1.item()['output']
    non_prediction = data_1.item()['prediction']

    # 生成训练集
    output_train = torch.cat((output[0],output[1]))
    for i in range(2,5000): # gtsrb:(2,900)
        output_train = torch.cat((output_train, output[i]))
    for i in range(10000,15000): # gtsrb:(1500,2400)
        output_train = torch.cat((output_train, output[i]))
    output_train = torch.tensor(output_train)


    prediction1 = prediction[:5000] # gtsrb:[:900]
    prediction2 = prediction[10000:15000] # gtsrb:[1500:2400]
    prediction_train = prediction1 + prediction2
    prediction_train = torch.tensor(prediction_train)
    prediction_train = prediction_train.view(-1,1)

    members_train = []
    for i in range(5000): # gtsrb:(900)
        members_train.append(members[i])
    for i in range(10000, 15000): # gtsrb:(1500, 2400)
        members_train.append(members[i])
    # for i in range(10000,14000): # gtsrb:(1500, 2400)
    #     members_train.append(members[i])
    members_train = torch.tensor(members_train)
    members_train = members_train.long()

    # 生成测试集
    output_test = torch.cat((output[5000],output[5001]))
    for i in range(5002,10000): # gtsrb:(902,1500)
        output_test = torch.cat((output_test, output[i]))
    for i in range(15000, 20000): # gtsrb:(2400, 3000)
        output_test = torch.cat((output_test, output[i]))
    output_test = torch.tensor(output_test)

    prediction3 = prediction[5000:10000] # gtsrb:[900:1500]
    prediction4 = prediction[15000:20000] # gtsrb:[2400:]
    prediction_test = prediction3 + prediction4
    prediction_test = torch.tensor(prediction_test)
    prediction_test = prediction_test.view(-1, 1)

    members_test = []
    for i in range(5000): # gtsrb:(900,1500)
        members_test.append(members[i])
    for i in range(10000, 15000): # gtsrb:(2400, 3000)
        members_test.append(members[i])
    members_test = torch.tensor(members_test)
    members_test = members_test.long()

    # print("train:",len(prediction_train))
    # print("train:", len(output_train))
    #
    # print("test:", len(prediction_test))
    # print("test:", len(output_test))

    with open(ATTACK_SETS + "train_5.p", "wb") as f:
        pickle.dump((output_train, prediction_train, members_train), f)
    # print("Finished Saving Train Dataset")

    with open(ATTACK_SETS + "test_5.p", "wb") as f:
        pickle.dump((output_test, prediction_test, members_test), f)
    # print("Finished Saving Test Dataset")

def input_1_gen():
    ATTACK_SETS = './attack_data/ratio/cinic10_resnet56/2000_10000/'
    device = utils.get_pytorch_device()

    with open(ATTACK_SETS + "test_0.p", "rb") as f:
        output_0, prediction_0, members_0 = pickle.load(f)
        output_0, prediction_0, members_0 = output_0.to(device), prediction_0.to(device), members_0.to(device)
    with open(ATTACK_SETS + "test_1.p", "rb") as f:
        output_1, prediction_1, _ = pickle.load(f)
        output_1, prediction_1 = output_1.to(device), prediction_1.to(device)
    with open(ATTACK_SETS + "test_2.p", "rb") as f:
        output_2, prediction_2, _ = pickle.load(f)
        output_2, prediction_2 = output_2.to(device), prediction_2.to(device)
    with open(ATTACK_SETS + "test_3.p", "rb") as f:
        output_3, prediction_3, _ = pickle.load(f)
        output_3, prediction_3 = output_3.to(device), prediction_3.to(device)
    with open(ATTACK_SETS + "test_4.p", "rb") as f:
        output_4, prediction_4, _ = pickle.load(f)
        output_4, prediction_4 = output_4.to(device), prediction_4.to(device)
    with open(ATTACK_SETS + "test_5.p", "rb") as f:
        output_5, prediction_5, _ = pickle.load(f)
        output_5, prediction_5 = output_5.to(device), prediction_5.to(device)

    output = torch.cat((output_0,output_1),1)
    output = torch.cat((output, output_2), 1)
    output = torch.cat((output, output_3), 1)
    output = torch.cat((output, output_4), 1)
    output = torch.cat((output, output_5), 1)

    prediction = torch.cat((prediction_0, prediction_1), 1)
    prediction = torch.cat((prediction, prediction_2), 1)
    prediction = torch.cat((prediction, prediction_3), 1)
    prediction = torch.cat((prediction, prediction_4), 1)
    prediction = torch.cat((prediction, prediction_5), 1)

    with open(ATTACK_SETS + "test.p", "wb") as f:
        pickle.dump((output, prediction, members_0), f)
    print("Finished Saving Train Dataset")

def train(device, attack_model, criterion, optimizer, epoch, result_path, ATTACK_SETS):
    batch_idx = 1
    train_loss = 0
    correct = 0
    total = 0

    final_train_gndtrth = []
    final_train_predict = []
    final_train_probabe = []

    final_result = []


    # with open(ATTACK_SETS + "train.p", "rb") as f:

    # output, prediction, members = pickle.load(f)
    # output, prediction, members = output.to(device), prediction.to(device), members.to(device)

    with open(ATTACK_SETS + "train.p", "rb") as f:
        output_0, prediction_0, members_0 = pickle.load(f)
        output_0, prediction_0, members_0 = output_0.to(device), prediction_0.to(device), members_0.to(device)



    attack_model.train()
    attack_model = attack_model.to(device)
    results = attack_model(output_0, prediction_0)
    results = F.softmax(results, dim=1)

    optimizer.zero_grad()
    losses = criterion(results, members_0)
    losses.backward()
    optimizer.step()

    train_loss += losses.item()
    _, predicted = results.max(1)
    total += members_0.size(0)
    correct += predicted.eq(members_0).sum().item()

    if epoch:
        final_train_gndtrth.append(members_0)
        final_train_predict.append(predicted)
        final_train_probabe.append(results[:, 1])

    batch_idx += 1


    if epoch:
        final_train_gndtrth = torch.cat(final_train_gndtrth, dim=0).cpu().detach().numpy()
        final_train_predict = torch.cat(final_train_predict, dim=0).cpu().detach().numpy()
        final_train_probabe = torch.cat(final_train_probabe, dim=0).cpu().detach().numpy()

        train_f1_score = f1_score(final_train_gndtrth, final_train_predict)
        train_roc_auc_score = roc_auc_score(final_train_gndtrth, final_train_probabe)

        final_result.append(train_f1_score)
        final_result.append(train_roc_auc_score)

        with open(result_path, "wb") as f:
            pickle.dump((final_train_gndtrth, final_train_predict, final_train_probabe), f)

        print("Saved Attack Train Ground Truth and Predict Sets")
        print("Train F1: %f\nAUC: %f" % (train_f1_score, train_roc_auc_score))

    final_result.append(1. * correct / total)
    print('Train Acc: %.3f%% (%d/%d) | Loss: %.3f' % (
    100. * correct / total, correct, total, 1. * train_loss / batch_idx))

    return final_result

def test(attack_model, device, epoch, result_path, test_acc, ATTACK_SETS):
    attack_model.eval()
    batch_idx = 1
    correct = 0
    total = 0

    final_test_gndtrth = []
    final_test_predict = []
    final_test_probabe = []

    final_result = []
    prediction = []

    with open(ATTACK_SETS + "test.p", "rb") as f:
        output_0, prediction_0, members_0 = pickle.load(f)
        output_0, prediction_0, members_0 = output_0.to(device), prediction_0.to(device), members_0.to(device)

    with torch.no_grad():
        results = attack_model(output_0, prediction_0)
        _, predicted = results.max(1)
        total += members_0.size(0)
        correct += predicted.eq(members_0).sum().item()
        results = F.softmax(results, dim=1)

        if epoch:
            final_test_gndtrth.append(members_0)
            final_test_predict.append(predicted)
            final_test_probabe.append(results[:, 1])

            for i in range(len(results)):
                pred = results[i, 1]
                pred = pred.cpu().detach().numpy()
                prediction.append(pred)  # prediction是置信度向量中的最大值

        batch_idx += 1


    if epoch:
        final_test_gndtrth = torch.cat(final_test_gndtrth, dim=0).cpu().numpy()
        final_test_predict = torch.cat(final_test_predict, dim=0).cpu().numpy()
        final_test_probabe = torch.cat(final_test_probabe, dim=0).cpu().numpy()

        test_f1_score = f1_score(final_test_gndtrth, final_test_predict)
        test_roc_auc_score = roc_auc_score(final_test_gndtrth, final_test_probabe)

        final_result.append(test_f1_score)
        final_result.append(test_roc_auc_score)

        with open(result_path, "wb") as f:
            pickle.dump((final_test_gndtrth, final_test_predict, final_test_probabe), f)


        members_0 = members_0.cpu().detach().numpy()
        predicted = predicted.cpu().detach().numpy()
        data = {
            'prediction': prediction,
            'true_label': members_0
        }

        np.save(f'./attack_data/roc/my_ad/gtsrb_vgg16bn/attack_data', data)

        print("Saved Attack Test Ground Truth and Predict Sets")
        print("Test F1: %f\nAUC: %f" % (test_f1_score, test_roc_auc_score))
        print('More detailed results:')
        print(classification_report(members_0, predicted))

    final_result.append(1. * correct / total)
    test_acc.append(1. * correct / total)
    print('Test Acc: %.3f%% (%d/%d)' % (100. * correct / (1.0 * total), correct, total))

    return final_result


def mia():
    ATTACK_SETS = './attack_data/output/Resnet/GTSRB/10000_10000/'

    # 定义attack model
    RESULT_PATH = './result'
    attack_model = PartialAttackModel(258) #258

    device = utils.get_pytorch_device()
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(attack_model.parameters(), lr=1e-5)
    test_acc = []

    for i in range(1000):
        flag = 1 if i == 999 else 0
        print("Epoch %d :" % (i+1))
        res_train = train(device, attack_model, criterion, optimizer, flag, RESULT_PATH, ATTACK_SETS)
        res_test = test(attack_model, device, flag, RESULT_PATH, test_acc, ATTACK_SETS)

    # 保存attack model
    network_path = ATTACK_SETS + 'attack_model'
    path = network_path + '/' + str(1000)
    torch.save(attack_model.state_dict(), path)  # ./networks/0/target/cifar100_resnet56/100存放的是模型的权重值

    epoches = []
    for i in range(1000):
        epoches.append(i)

    plt.figure(figsize=(20, 15))  # 设置绘图大小为20*15
    plt.xlabel('epoch')  # 设置x、y轴标签
    plt.ylabel('test acc')
    plt.title('Test Acc')  # 设置绘图标题
    plt.plot(epoches, test_acc)  # 以epoches为横坐标、test_acc为纵坐标绘制折线图
    plt.savefig(ATTACK_SETS + 'Test_Acc.png')  # 保存绘图为png图片
    #plt.show()  # 程序运行时显示绘图，且阻止命令继续往下运行，关闭绘图后命令会继续运行

    max_acc = max(test_acc)
    print(max_acc)
    with open(ATTACK_SETS + "test_accuracy.p", "wb") as f:
        pickle.dump(test_acc, f)



if __name__ == '__main__':
    action = 0

    # 训练、测试attack model
    if action == 0:
        start = time.time()
        mia()
        end = time.time()
        print("程序用时：", end - start, "秒")

    # 拼接
    if action == 1:
        input_1_gen()

    # 生成attack model的训练集和测试集
    if action == 2:
        start = time.time()
        prepare_dataset()
        end = time.time()
        print("程序用时：", end - start, "秒")