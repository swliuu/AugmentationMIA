import torch
import os 
from torchvision import datasets, transforms, utils
from torch.utils.data import sampler
from PIL import Image
from torch.utils.data import Subset, DataLoader, ConcatDataset, Dataset
import torch.utils.data as data
from torch._utils import _accumulate
from torch import randperm
import numpy as np
import pandas as pd



class MaskDataset(Dataset):
    def __init__(self, dataset: Dataset, mask: torch.Tensor):
        """
        example:
        mask: [0, 1, 1]
        cumul: [-1, 0, 1]
        remap: {0: 1, 1: 2}
        """
        assert mask.dim() == 1
        assert mask.size(0) == len(dataset)
        assert mask.dtype == torch.bool

        mask = mask.long()
        cumul = torch.cumsum(mask, dim=0) - 1
        self.remap = {}
        for i in range(mask.size(0)):
            if mask[i] == 1:
                self.remap[cumul[i].item()] = i
            assert mask[i] in [0, 1]

        self.dataset = dataset
        self.mask = mask
        self.length = cumul[-1].item() + 1

    def __getitem__(self, i: int):
        return self.dataset[self.remap[i]]

    def __len__(self):
        return self.length



def dataset_split(dataset, lengths):
    if sum(lengths) != len(dataset):
        raise ValueError("Sum of input lengths does not equal the length of the input dataset!")
    
    indices = list(range(sum(lengths)))
    np.random.seed(1)
    np.random.shuffle(indices)
    return [Subset(dataset, indices[offset - length:offset]) for offset, length in zip(_accumulate(lengths), lengths)]

    return all_data

class GTSRB_ORI(data.Dataset):
    base_folder = 'GTSRB'
    def __init__(self, root_dir, train=False, transform=None):

        self.train = train
        self.root_dir = root_dir
        self.sub_directory = 'csv_train' if train else 'csv_test'

        self.csv_file_name = 'train_data.csv' if train else 'test_data.csv'

        csv_file_path = os.path.join(
            root_dir, self.base_folder, self.sub_directory, self.csv_file_name)

        self.csv_data = pd.read_csv(csv_file_path)

        self.transform = transform

    def __len__(self):
        return len(self.csv_data)

    def __getitem__(self, idx):
        if self.train:
            img_path = os.path.join(self.csv_data.iloc[idx, 0])
        else:
            img_path = os.path.join(self.root_dir, self.base_folder, self.csv_data.iloc[idx, 0])

        img = Image.open(img_path)
        classId = self.csv_data.iloc[idx, 1]
        if self.transform is not None:
            img = self.transform(img)

        return img, classId





class SUBGTSRB(data.Dataset):
    def __init__(self, mode, aug, train, type):
        self.img_size = 32
        self.num_classes = 43
        self.mean = [0.3403, 0.3121, 0.3214]
        self.std = [0.2724, 0.2608, 0.2669]
        normalize = transforms.Normalize(mean=self.mean, std=self.std)
        self.augmented = transforms.Compose([transforms.Resize((32,32)), transforms.ToTensor(), normalize])
        self.normalized = transforms.Compose([transforms.Resize((32,32)), transforms.ToTensor(), normalize])

        if type == 0:
            self.normalized = transforms.Compose([transforms.Resize((32,32)), transforms.ToTensor(), normalize])
            self.augmented = self.normalized
        elif type == 1:
            self.augmented = transforms.Compose(
                [transforms.Resize((32,32)), transforms.RandomHorizontalFlip(), transforms.RandomCrop(32, padding=4), transforms.ToTensor(),
                 normalize])
        elif type == 2:
            self.augmented = transforms.Compose(
                [transforms.Resize((32,32)), transforms.RandomHorizontalFlip(p=1),  transforms.ToTensor(),
                 normalize])
        elif type == 3:
            self.augmented = transforms.Compose(
                [transforms.Resize((32,32)), transforms.RandomCrop(32, padding=4),  transforms.ToTensor(),
                 normalize])
        elif type == 4:
            self.augmented = transforms.Compose(
                [transforms.Resize((32,32)), transforms.RandomVerticalFlip(p=0.5), transforms.ToTensor(),
                 normalize])
        elif type == 5:
            self.augmented = transforms.Compose(
                [transforms.Resize((32,32)), transforms.ColorJitter(hue=0.4), transforms.ToTensor(),
                 normalize])

        self.aug_trainset = GTSRB_ORI(root_dir='D:\datasets', train=True, transform=self.augmented)
        self.aug_testset = GTSRB_ORI(root_dir='D:\datasets', train=False, transform=self.augmented)
        self.trainset = GTSRB_ORI(root_dir='D:\datasets', train=True, transform=self.normalized)
        self.testset = GTSRB_ORI(root_dir='D:\datasets', train=False, transform=self.normalized)


        self.aug_dataset = ConcatDataset([self.aug_trainset, self.aug_testset])
        self.dataset = ConcatDataset([self.trainset, self.testset])
        print('datasets', len(self.dataset))

        self.aug_target_trainset, self.aug_target_testset, self.aug_shadow_trainset, self.aug_shadow_testset, self.aug_distill_trainset = dataset_split(self.aug_dataset, [1500, 1500, 1500, 1500, 45837])

        self.aug_distill_testset = self.aug_shadow_testset
        self.target_trainset, self.target_testset, self.shadow_trainset, self.shadow_testset, self.distill_trainset = dataset_split(self.dataset, [1500, 1500, 1500, 1500, 45837])
        self.distill_testset = self.shadow_testset

        if mode == 'target':
            if aug:
                if train:
                    self.dataset = self.aug_target_trainset
                else:
                    self.dataset = self.aug_target_testset
            else:
                if train:
                    self.dataset = self.target_trainset
                else:
                    self.dataset = self.target_testset
        elif mode == 'shadow':
            if aug:
                if train:
                    self.dataset = self.aug_shadow_trainset
                else:
                    self.dataset = self.aug_shadow_testset
            else:
                if train:
                    self.dataset = self.shadow_trainset
                else:
                    self.dataset = self.shadow_testset
        elif 'distill' in mode:
            if aug:
                if train:
                    self.dataset = self.aug_distill_trainset
                else:
                    self.dataset = self.aug_distill_testset
            else:
                if train:
                    self.dataset = self.distill_trainset
                else:
                    self.dataset = self.distill_testset

        self.index = range(int(len(self.dataset)))


    def __getitem__(self, idx):
        return self.dataset[idx][0], self.dataset[idx][1], self.index[idx]

    def __len__(self):
        return len(self.index)
        
class GTSRB:
    def __init__(self, mode, aug, batch_size=128):
        self.batch_size = batch_size
        self.img_size = 32
        self.num_classes = 43
 
        if aug:
            if mode == 'target':
                self.aug_target_trainset = SUBGTSRB(mode, aug, True)
                self.aug_target_train_loader = torch.utils.data.DataLoader(self.aug_target_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.aug_target_testset = SUBGTSRB(mode, aug, False)
                self.aug_target_test_loader = torch.utils.data.DataLoader(self.aug_target_testset, batch_size=batch_size, shuffle=True, num_workers=1)
            elif mode == 'shadow':
                self.aug_shadow_trainset = SUBGTSRB(mode, aug, True)
                self.aug_shadow_train_loader = torch.utils.data.DataLoader(self.aug_shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.aug_shadow_testset = SUBGTSRB(mode, aug, False)
                self.aug_shadow_test_loader = torch.utils.data.DataLoader(self.aug_shadow_testset, batch_size=batch_size, shuffle=True, num_workers=1)
            elif 'distill' in mode:
                self.aug_distill_trainset = SUBGTSRB(mode, aug, True)
                self.aug_distill_train_loader = torch.utils.data.DataLoader(self.aug_distill_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.aug_distill_testset = SUBGTSRB(mode, aug, False)
                self.aug_distill_test_loader = torch.utils.data.DataLoader(self.aug_distill_testset, batch_size=batch_size, shuffle=True, num_workers=1)

        else:
            if mode == 'target':
                self.target_trainset = SUBGTSRB(mode, aug, True, 0)
                self.target_train_loader = torch.utils.data.DataLoader(self.target_trainset, batch_size=batch_size, shuffle=False, num_workers=1)

                self.target_testset = SUBGTSRB(mode, aug, False, 0)
                self.target_test_loader = torch.utils.data.DataLoader(self.target_testset, batch_size=batch_size, shuffle=False, num_workers=1)

                self.target_trainset_aug1 = SUBGTSRB(mode, True, True, type=1)  # Horizontal_Flip
                self.target_train_aug_loader1 = torch.utils.data.DataLoader(self.target_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug2 = SUBGTSRB(mode, True, True, type=2)  # Horizontal_Flip
                self.target_train_aug_loader2 = torch.utils.data.DataLoader(self.target_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug3 = SUBGTSRB(mode, True, True, type=3)  # 数据增强：Crop
                self.target_train_aug_loader3 = torch.utils.data.DataLoader(self.target_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug4 = SUBGTSRB(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_train_aug_loader4 = torch.utils.data.DataLoader(self.target_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug5 = SUBGTSRB(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_train_aug_loader5 = torch.utils.data.DataLoader(self.target_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_testset_aug1 = SUBGTSRB(mode, True, False, type=1)  # 数据增强：Horizontal_Flip
                self.target_test_aug_loader1 = torch.utils.data.DataLoader(self.target_testset_aug1,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug2 = SUBGTSRB(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.target_test_aug_loader2 = torch.utils.data.DataLoader(self.target_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug3 = SUBGTSRB(mode, True, False, type=3)  # 数据增强：Crop
                self.target_test_aug_loader3 = torch.utils.data.DataLoader(self.target_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug4 = SUBGTSRB(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_test_aug_loader4 = torch.utils.data.DataLoader(self.target_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug5 = SUBGTSRB(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_test_aug_loader5 = torch.utils.data.DataLoader(self.target_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

            elif mode == 'shadow':
                self.shadow_trainset = SUBGTSRB(mode, aug, True, type=0)
                self.shadow_train_loader = torch.utils.data.DataLoader(self.shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.shadow_testset = SUBGTSRB(mode, aug, False, type=0)
                self.shadow_test_loader = torch.utils.data.DataLoader(self.shadow_testset, batch_size=batch_size, shuffle=True, num_workers=1)

                self.shadow_trainset_aug1 = SUBGTSRB(mode, True, True, type=1)  # Pad
                self.shadow_train_aug_loader1 = torch.utils.data.DataLoader(self.shadow_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)
                self.shadow_trainset_aug2 = SUBGTSRB(mode, True, True, type=2)  # Horizontal_Flip
                self.shadow_train_aug_loader2 = torch.utils.data.DataLoader(self.shadow_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug3 = SUBGTSRB(mode, True, True, type=3)  # 数据增强：Crop
                self.shadow_train_aug_loader3 = torch.utils.data.DataLoader(self.shadow_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_trainset_aug4 = SUBGTSRB(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.shadow_train_aug_loader4 = torch.utils.data.DataLoader(self.shadow_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug5 = SUBGTSRB(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.shadow_train_aug_loader5 = torch.utils.data.DataLoader(self.shadow_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_testset_aug1 = SUBGTSRB(mode, True, False, type=1)  # Pad
                self.shadow_test_aug_loader1 = torch.utils.data.DataLoader(self.shadow_testset_aug1,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug2 = SUBGTSRB(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.shadow_test_aug_loader2 = torch.utils.data.DataLoader(self.shadow_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug3 = SUBGTSRB(mode, True, False, type=3)  # 数据增强：Crop
                self.shadow_test_aug_loader3 = torch.utils.data.DataLoader(self.shadow_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug4 = SUBGTSRB(mode, True, False, type=4)  # 数据增强：Vertical_Flip
                self.shadow_test_aug_loader4 = torch.utils.data.DataLoader(self.shadow_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug5 = SUBGTSRB(mode, True, False, type=5)  # 数据增强：ColorJitter
                self.shadow_test_aug_loader5 = torch.utils.data.DataLoader(self.shadow_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

            elif 'distill' in mode:
                self.distill_trainset = SUBGTSRB(mode, aug, True)
                self.distill_train_loader = torch.utils.data.DataLoader(self.distill_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.distill_testset = SUBGTSRB(mode, aug, False)
                self.distill_test_loader = torch.utils.data.DataLoader(self.distill_testset, batch_size=batch_size, shuffle=True, num_workers=1)

class SUBCINIC10(data.Dataset):
    def __init__(self, mode, aug, train, type):
        self.img_size = 32
        self.num_classes = 10
        self.mean = [0.47889522, 0.47227842, 0.43047404]
        self.std = [0.24205776, 0.23828046, 0.25874835]
        normalize = transforms.Normalize(mean=self.mean, std=self.std)

        self.augmented = transforms.Compose([transforms.RandomHorizontalFlip(), transforms.RandomCrop(32, padding=4),transforms.ToTensor(), normalize])
        self.normalized = transforms.Compose([transforms.ToTensor(), normalize])

        if type == 0:
            self.normalized = transforms.Compose([transforms.ToTensor(), normalize])
            self.augmented = self.normalized
        elif type == 1:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(), transforms.RandomCrop(32, padding=4), transforms.ToTensor(),
                 normalize])
        elif type == 2:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(p=0.5),  transforms.ToTensor(),
                 normalize])
        elif type == 3:
            self.augmented = transforms.Compose(
                [transforms.RandomCrop(32, padding=4),  transforms.ToTensor(),
                 normalize])
        elif type == 4:
            self.augmented = transforms.Compose(
                [transforms.RandomVerticalFlip(p=0.5)  , transforms.ToTensor(),
                 normalize])

        elif type == 5:
            self.augmented = transforms.Compose(
                [transforms.ColorJitter(brightness=10), transforms.ToTensor(),
                 normalize])

        self.aug_trainset =  datasets.ImageFolder(root='D:/datasets/CINIC-10/train', transform=self.augmented)
        self.aug_testset =  datasets.ImageFolder(root='D:/datasets/CINIC-10/test', transform=self.augmented)
        self.aug_validset =  datasets.ImageFolder(root='D:/datasets/CINIC-10/valid', transform=self.augmented)
        self.trainset =  datasets.ImageFolder(root='D:/datasets/CINIC-10/train', transform=self.normalized)
        self.testset =  datasets.ImageFolder(root='D:/datasets/CINIC-10/test', transform=self.normalized)
        self.validset =  datasets.ImageFolder(root='D:/datasets/CINIC-10/valid', transform=self.normalized)

        self.aug_dataset = ConcatDataset([self.aug_trainset, self.aug_testset, self.aug_validset])
        self.dataset = ConcatDataset([self.trainset, self.testset, self.validset])
        
        self.aug_target_trainset, self.aug_target_testset, self.aug_shadow_trainset, self.aug_shadow_testset, self.aug_distill_trainset, self.aug_distill_testset = dataset_split(self.aug_dataset, [10000, 10000, 20000, 10000, 210000, 10000])
        self.target_trainset, self.target_testset, self.shadow_trainset, self.shadow_testset, self.distill_trainset, self.distill_testset = dataset_split(self.dataset, [10000, 10000, 20000, 10000, 210000, 10000])

        if mode == 'target':
            if aug:
                if train:
                    self.dataset = self.aug_target_trainset
                else:
                    self.dataset = self.aug_target_testset
            else:
                if train:
                    self.dataset = self.target_trainset
                else:
                    self.dataset = self.target_testset
        elif mode == 'shadow':
            if aug:
                if train:
                    self.dataset = self.aug_shadow_trainset
                else:
                    self.dataset = self.aug_shadow_testset
            else:
                if train:
                    self.dataset = self.shadow_trainset
                else:
                    self.dataset = self.shadow_testset
        elif 'distill' in mode:
            if aug:
                if train:
                    self.dataset = self.aug_distill_trainset
                else:
                    self.dataset = self.aug_distill_testset
            else:
                if train:
                    self.dataset = self.distill_trainset
                else:
                    self.dataset = self.distill_testset

        self.index = range(int(len(self.dataset)))


    def __getitem__(self, idx):
        return self.dataset[idx][0], self.dataset[idx][1], self.index[idx]

    def __len__(self):
        return len(self.index)

class CINIC10:
    def __init__(self, mode, aug, batch_size=128, add_trigger=False):
        self.batch_size = batch_size
        self.img_size = 32
        self.num_classes = 10

        if aug:
            if mode == 'target':
                self.aug_target_trainset = SUBCINIC10(mode, aug, True)
                self.aug_target_train_loader = torch.utils.data.DataLoader(self.aug_target_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.aug_target_testset = SUBCINIC10(mode, aug, False)
                self.aug_target_test_loader = torch.utils.data.DataLoader(self.aug_target_testset, batch_size=batch_size, shuffle=True, num_workers=2)
            elif mode == 'shadow':
                self.aug_shadow_trainset = SUBCINIC10(mode, aug, True)
                self.aug_shadow_train_loader = torch.utils.data.DataLoader(self.aug_shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.aug_shadow_testset = SUBCINIC10(mode, aug, False)
                self.aug_shadow_test_loader = torch.utils.data.DataLoader(self.aug_shadow_testset, batch_size=batch_size, shuffle=True, num_workers=2)
            elif 'distill' in mode:
                self.aug_distill_trainset = SUBCINIC10(mode, aug, True)
                self.aug_distill_train_loader = torch.utils.data.DataLoader(self.aug_distill_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.aug_distill_testset = SUBCINIC10(mode, aug, False)
                self.aug_distill_test_loader = torch.utils.data.DataLoader(self.aug_distill_testset, batch_size=batch_size, shuffle=True, num_workers=2)

        else:
            if mode == 'target':
                self.target_trainset = SUBCINIC10(mode, aug, True, 0)
                self.target_train_loader = torch.utils.data.DataLoader(self.target_trainset, batch_size=batch_size, shuffle=False, num_workers=0)
                self.target_testset = SUBCINIC10(mode, aug, False, 0)
                self.target_test_loader = torch.utils.data.DataLoader(self.target_testset, batch_size=batch_size, shuffle=False, num_workers=0)

                self.target_trainset_aug1 = SUBCINIC10(mode, True, True, type=1)
                self.target_train_aug_loader1 = torch.utils.data.DataLoader(self.target_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug2 = SUBCINIC10(mode, True, True, type=2)  # Horizontal_Flip
                self.target_train_aug_loader2 = torch.utils.data.DataLoader(self.target_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug3 = SUBCINIC10(mode, True, True, type=3)  # 数据增强：Crop
                self.target_train_aug_loader3 = torch.utils.data.DataLoader(self.target_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug4 = SUBCINIC10(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_train_aug_loader4 = torch.utils.data.DataLoader(self.target_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug5 = SUBCINIC10(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_train_aug_loader5 = torch.utils.data.DataLoader(self.target_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_testset_aug1 = SUBCINIC10(mode, True, False, type=1)  # 数据增强：Horizontal_Flip
                self.target_test_aug_loader1 = torch.utils.data.DataLoader(self.target_testset_aug1,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug2 = SUBCINIC10(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.target_test_aug_loader2 = torch.utils.data.DataLoader(self.target_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug3 = SUBCINIC10(mode, True, False, type=3)  # 数据增强：Crop
                self.target_test_aug_loader3 = torch.utils.data.DataLoader(self.target_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug4 = SUBCINIC10(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_test_aug_loader4 = torch.utils.data.DataLoader(self.target_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug5 = SUBCINIC10(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_test_aug_loader5 = torch.utils.data.DataLoader(self.target_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)
            elif mode == 'shadow':
                self.shadow_trainset = SUBCINIC10(mode, aug, True, type=0)
                self.shadow_train_loader = torch.utils.data.DataLoader(self.shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.shadow_testset = SUBCINIC10(mode, aug, False, type=0)
                self.shadow_test_loader = torch.utils.data.DataLoader(self.shadow_testset, batch_size=batch_size, shuffle=True, num_workers=2)

                self.shadow_trainset_aug1 = SUBCINIC10(mode, True, True, type=1)  # Pad
                self.shadow_train_aug_loader1 = torch.utils.data.DataLoader(self.shadow_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)
                self.shadow_trainset_aug2 = SUBCINIC10(mode, True, True, type=2)  # Horizontal_Flip
                self.shadow_train_aug_loader2 = torch.utils.data.DataLoader(self.shadow_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug3 = SUBCINIC10(mode, True, True, type=3)  # 数据增强：Crop
                self.shadow_train_aug_loader3 = torch.utils.data.DataLoader(self.shadow_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_trainset_aug4 = SUBCINIC10(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.shadow_train_aug_loader4 = torch.utils.data.DataLoader(self.shadow_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug5 = SUBCINIC10(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.shadow_train_aug_loader5 = torch.utils.data.DataLoader(self.shadow_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_testset_aug1 = SUBCINIC10(mode, True, False, type=1)  # Pad
                self.shadow_test_aug_loader1 = torch.utils.data.DataLoader(self.shadow_testset_aug1,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug2 = SUBCINIC10(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.shadow_test_aug_loader2 = torch.utils.data.DataLoader(self.shadow_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug3 = SUBCINIC10(mode, True, False, type=3)  # 数据增强：Crop
                self.shadow_test_aug_loader3 = torch.utils.data.DataLoader(self.shadow_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug4 = SUBCINIC10(mode, True, False, type=4)  # 数据增强：Vertical_Flip
                self.shadow_test_aug_loader4 = torch.utils.data.DataLoader(self.shadow_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug5 = SUBCINIC10(mode, True, False, type=5)  # 数据增强：ColorJitter
                self.shadow_test_aug_loader5 = torch.utils.data.DataLoader(self.shadow_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

            elif 'distill' in mode:
                self.distill_trainset = SUBCINIC10(mode, aug, True)
                self.distill_train_loader = torch.utils.data.DataLoader(self.distill_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.distill_testset = SUBCINIC10(mode, aug, False)
                self.distill_test_loader = torch.utils.data.DataLoader(self.distill_testset, batch_size=batch_size, shuffle=True, num_workers=2)


class SUBMNIST(data.Dataset):
    def __init__(self, mode, aug, train, type):
        self.img_size = 28
        self.num_classes = 10
        self.num_test = 10000
        self.num_train = 60000
        self.mean = [0.1307]
        self.std = [0.3081]
        normalize = transforms.Normalize(mean=self.mean, std=self.std)

        if type == 0:
            self.normalized = transforms.Compose([transforms.ToTensor(), normalize])
            self.augmented = self.normalized
        elif type == 1:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(), transforms.RandomCrop(28, padding=4), transforms.ToTensor(),
                 normalize])
        elif type == 2:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(p=0.5), transforms.ToTensor(),
                 normalize])
        elif type == 3:
            self.augmented = transforms.Compose(
                [transforms.RandomCrop(28, padding=4), transforms.ToTensor(),
                 normalize])
        elif type == 4:
            self.augmented = transforms.Compose(
                [transforms.RandomVerticalFlip(p=0.5), transforms.ToTensor(),
                 normalize])

        elif type == 5:
            self.augmented = transforms.Compose(
                [transforms.ColorJitter(brightness=10), transforms.ToTensor(),
                 normalize])

        self.normalized = transforms.Compose([transforms.ToTensor(), normalize])

        self.aug_trainset = datasets.MNIST(root='/home/c01yili/datasets/common_dataset', train=True, download=True,
                                             transform=self.augmented)
        self.aug_testset = datasets.MNIST(root='/home/c01yili/datasets/common_dataset', train=False, download=True,
                                            transform=self.augmented)
        self.trainset = datasets.MNIST(root='/home/c01yili/datasets/common_dataset', train=True, download=True,
                                         transform=self.normalized)
        self.testset = datasets.MNIST(root='/home/c01yili/datasets/common_dataset', train=False, download=True,
                                        transform=self.normalized)

        self.aug_dataset = ConcatDataset([self.aug_trainset, self.aug_testset])
        self.dataset = ConcatDataset([self.trainset, self.testset])

        self.aug_target_trainset, self.aug_target_testset, self.aug_shadow_trainset, self.aug_shadow_testset, self.aug_distill_trainset = dataset_split(
            self.aug_dataset, [10000, 10000, 10000, 10000, 30000])
        self.aug_distill_testset = self.aug_shadow_testset
        self.target_trainset, self.target_testset, self.shadow_trainset, self.shadow_testset, self.distill_trainset = dataset_split(
            self.dataset, [10000, 10000, 10000, 10000, 30000])
        self.distill_testset = self.shadow_testset

        if mode == 'target':
            if aug:
                if train:
                    self.dataset = self.aug_target_trainset
                else:
                    self.dataset = self.aug_target_testset
            else:
                if train:
                    self.dataset = self.target_trainset
                else:
                    self.dataset = self.target_testset
        elif mode == 'shadow':
            if aug:
                if train:
                    self.dataset = self.aug_shadow_trainset
                else:
                    self.dataset = self.aug_shadow_testset
            else:
                if train:
                    self.dataset = self.shadow_trainset
                else:
                    self.dataset = self.shadow_testset
        elif 'distill' in mode:
            if aug:
                if train:
                    self.dataset = self.aug_distill_trainset
                else:
                    self.dataset = self.aug_distill_testset
            else:
                if train:
                    self.dataset = self.distill_trainset
                else:
                    self.dataset = self.distill_testset

        self.index = range(int(len(self.dataset)))

    def __getitem__(self, idx):
        return self.dataset[idx][0], self.dataset[idx][1], self.index[idx]

    def __len__(self):
        return len(self.index)


class MNIST:
    def __init__(self, mode, aug, batch_size=128, add_trigger=False):
        self.batch_size = batch_size
        self.img_size = 28
        self.num_classes = 10

        if aug:
            if mode == 'target':
                self.aug_target_trainset = SUBMNIST(mode, aug, True)
                self.aug_target_train_loader = torch.utils.data.DataLoader(self.aug_target_trainset,
                                                                           batch_size=batch_size, shuffle=True,
                                                                           num_workers=2)
                self.aug_target_testset = SUBMNIST(mode, aug, False)
                self.aug_target_test_loader = torch.utils.data.DataLoader(self.aug_target_testset,
                                                                          batch_size=batch_size, shuffle=True,
                                                                          num_workers=2)
            elif mode == 'shadow':
                self.aug_shadow_trainset = SUBMNIST(mode, aug, True)
                self.aug_shadow_train_loader = torch.utils.data.DataLoader(self.aug_shadow_trainset,
                                                                           batch_size=batch_size, shuffle=True,
                                                                           num_workers=2)
                self.aug_shadow_testset = SUBMNIST(mode, aug, False)
                self.aug_shadow_test_loader = torch.utils.data.DataLoader(self.aug_shadow_testset,
                                                                          batch_size=batch_size, shuffle=True,
                                                                          num_workers=2)
            elif 'distill' in mode:
                self.aug_distill_trainset = SUBMNIST(mode, aug, True)
                self.aug_distill_train_loader = torch.utils.data.DataLoader(self.aug_distill_trainset,
                                                                            batch_size=batch_size, shuffle=True,
                                                                            num_workers=2)
                self.aug_distill_testset = SUBMNIST(mode, aug, False)
                self.aug_distill_test_loader = torch.utils.data.DataLoader(self.aug_distill_testset,
                                                                           batch_size=batch_size, shuffle=True,
                                                                           num_workers=2)

        else:  # aug = False
            if mode == 'target':
                self.target_trainset = SUBMNIST(mode, aug, True, 0)  # 加载target model的训练集
                self.target_train_loader = torch.utils.data.DataLoader(self.target_trainset, batch_size=batch_size,
                                                                       shuffle=False, num_workers=2)

                self.target_testset = SUBMNIST(mode, aug, False, 0)  # 加载target model的测试集
                self.target_test_loader = torch.utils.data.DataLoader(self.target_testset, batch_size=batch_size,
                                                                      shuffle=False, num_workers=2)

                self.target_trainset_aug2 = SUBMNIST(mode, True, True, type=2)  # Horizontal_Flip
                self.target_train_aug_loader2 = torch.utils.data.DataLoader(self.target_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug3 = SUBMNIST(mode, True, True, type=3)  # 数据增强：Crop
                self.target_train_aug_loader3 = torch.utils.data.DataLoader(self.target_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug4 = SUBMNIST(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_train_aug_loader4 = torch.utils.data.DataLoader(self.target_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug5 = SUBMNIST(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_train_aug_loader5 = torch.utils.data.DataLoader(self.target_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_testset_aug2 = SUBMNIST(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.target_test_aug_loader2 = torch.utils.data.DataLoader(self.target_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug3 = SUBMNIST(mode, True, False, type=3)  # 数据增强：Crop
                self.target_test_aug_loader3 = torch.utils.data.DataLoader(self.target_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug4 = SUBMNIST(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_test_aug_loader4 = torch.utils.data.DataLoader(self.target_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug5 = SUBMNIST(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_test_aug_loader5 = torch.utils.data.DataLoader(self.target_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)



            elif mode == 'shadow':
                self.shadow_trainset = SUBMNIST(mode, aug, True)
                self.shadow_train_loader = torch.utils.data.DataLoader(self.shadow_trainset, batch_size=batch_size,
                                                                       shuffle=True, num_workers=2)
                self.shadow_testset = SUBMNIST(mode, aug, False)
                self.shadow_test_loader = torch.utils.data.DataLoader(self.shadow_testset, batch_size=batch_size,
                                                                      shuffle=True, num_workers=2)
            elif 'distill' in mode:
                self.distill_trainset = SUBMNIST(mode, aug, True)
                self.distill_train_loader = torch.utils.data.DataLoader(self.distill_trainset, batch_size=batch_size,
                                                                        shuffle=True, num_workers=2)
                self.distill_testset = SUBMNIST(mode, aug, False)
                self.distill_test_loader = torch.utils.data.DataLoader(self.distill_testset, batch_size=batch_size,
                                                                       shuffle=True, num_workers=2)


class SUBCIFAR10(data.Dataset):
    def __init__(self, mode, aug, train, type):
        self.img_size = 32
        self.num_classes = 10
        self.num_test = 10000
        self.num_train = 50000
        self.mean = [0.485, 0.456, 0.406]
        self.std = [0.229, 0.224, 0.225]
        normalize = transforms.Normalize(mean=self.mean, std=self.std)

        if type == 0:
            self.normalized = transforms.Compose([transforms.ToTensor(), normalize])
            self.augmented = self.normalized
        elif type == 1:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(), transforms.RandomCrop(32, padding=4), transforms.ToTensor(),
                 normalize])
            # self.augmented = transforms.Compose(
            #     [transforms.RandomHorizontalFlip(0.4), transforms.ToTensor(),
            #      normalize])
            # self.augmented = transforms.Compose(
            #    [transforms.Pad(padding=4, fill=(255, 0, 0), padding_mode='constant'), transforms.ToTensor(),
            #      normalize])

        elif type == 2:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(p=1),  transforms.ToTensor(),
                 normalize])
            # self.augmented = transforms.Compose(
            #     [transforms.ColorJitter(brightness=10), transforms.RandomHorizontalFlip(p=0.5), transforms.ToTensor(),
            #      normalize])
        elif type == 3:
            self.augmented = transforms.Compose(
                [transforms.RandomCrop(32, padding=4),  transforms.ToTensor(),
                 normalize])
            # self.augmented = transforms.Compose(
            #     [transforms.RandomHorizontalFlip(p=0.1), transforms.ToTensor(),
            #      normalize])
        elif type == 4:
            self.augmented = transforms.Compose(
                [transforms.RandomVerticalFlip(p=0.5)  , transforms.ToTensor(),
                 normalize])
            # self.augmented = transforms.Compose(
            #     [transforms.RandomHorizontalFlip(p=0.2), transforms.ToTensor(),
            #      normalize])

        elif type == 5:
            self.augmented = transforms.Compose(
                [transforms.ColorJitter(brightness=1), transforms.ToTensor(),
                 normalize])
            # self.augmented = transforms.Compose(
            #     [transforms.RandomHorizontalFlip(p=0.3), transforms.ToTensor(),
            #      normalize])

        elif type == 6:
            self.augmented = transforms.Compose(
                [transforms.RandomRotation(90), transforms.ToTensor(),
                 normalize])

        elif type == 7:
            self.augmented = transforms.Compose(
                [transforms.RandomAffine(degrees=30), transforms.ToTensor(),
                 normalize])

        elif type == 8:
            self.augmented = transforms.Compose(
                [transforms.ColorJitter(hue=0.5), transforms.ToTensor(),
                 normalize])


        self.normalized = transforms.Compose([transforms.ToTensor(), normalize])

        self.aug_trainset =  datasets.CIFAR10(root='/home/c01yili/datasets/common_dataset', train=True, download=True, transform=self.augmented)
        self.aug_testset =  datasets.CIFAR10(root='/home/c01yili/datasets/common_dataset', train=False, download=True, transform=self.augmented)
        self.trainset =  datasets.CIFAR10(root='/home/c01yili/datasets/common_dataset', train=True, download=True, transform=self.normalized)
        self.testset =  datasets.CIFAR10(root='/home/c01yili/datasets/common_dataset', train=False, download=True, transform=self.normalized)

        self.aug_dataset = ConcatDataset([self.aug_trainset, self.aug_testset])
        self.dataset = ConcatDataset([self.trainset, self.testset])
        
        self.aug_target_trainset, self.aug_target_testset, self.aug_shadow_trainset, self.aug_shadow_testset, self.aug_distill_trainset = dataset_split(self.aug_dataset, [10000, 10000, 20000, 10000, 10000])
        self.aug_distill_testset = self.aug_shadow_testset

        self.target_trainset, self.target_testset, self.shadow_trainset, self.shadow_testset, self.distill_trainset = dataset_split(self.dataset, [10000, 10000, 20000, 10000, 10000])


        # 加载目标模型训练集、测试集
        # self.d1, self.d2, self.d3, self.d4, self.d5 = dataset_split(self.dataset, [10000, 10000, 10000, 10000, 20000])
        # self.dataset = ConcatDataset([self.d1, self.d2, self.d3, self.d4])
        # target_train_path = 'mask/hidden/train.pth'  # 加载目标模型训练集的mask
        # target_train_mask = torch.load(target_train_path)
        # self.target_trainset = MaskDataset(self.dataset, target_train_mask)
        #
        # target_test_path = 'mask/hidden/heldout.pth'  # 加载目标模型训练集的mask
        # target_test_mask = torch.load(target_test_path)
        # self.target_testset = MaskDataset(self.dataset, target_test_mask)


        # 加载攻击模型训练集、测试集
        # attack_train_path = 'mask/hidden/public_train.pth'  # 加载目标模型训练集的mask
        # attack_train_mask = torch.load(attack_train_path)
        # self.target_trainset = MaskDataset(self.dataset, attack_train_mask)
        #
        # attack_test_path = 'mask/hidden/public_heldout.pth'  # 加载目标模型训练集的mask
        # attack_test_mask = torch.load(attack_test_path)
        # self.target_testset = MaskDataset(self.dataset, attack_test_mask)


        #self.distill_testset = self.shadow_testset

        if mode == 'target':
            if aug:
                if train:
                    self.dataset = self.aug_target_trainset
                else:
                    self.dataset = self.aug_target_testset
            else:
                if train:
                    self.dataset = self.target_trainset
                else:
                    self.dataset = self.target_testset
        elif mode == 'shadow':
            if aug:
                if train:
                    self.dataset = self.aug_shadow_trainset
                else:
                    self.dataset = self.aug_shadow_testset
            else:
                if train:
                    self.dataset = self.shadow_trainset
                else:
                    self.dataset = self.shadow_testset
        elif 'distill' in mode:
            if aug:
                if train:
                    self.dataset = self.aug_distill_trainset
                else:
                    self.dataset = self.aug_distill_testset
            else:
                if train:
                    self.dataset = self.distill_trainset
                else:
                    self.dataset = self.distill_testset

        self.index = range(int(len(self.dataset)))


    def __getitem__(self, idx):
        return self.dataset[idx][0], self.dataset[idx][1], self.index[idx]

    def __len__(self):
        return len(self.index)

class CIFAR10:
    def __init__(self, mode, aug, batch_size=128, add_trigger=False):
        self.batch_size = batch_size
        self.img_size = 32
        self.num_classes = 10

        if aug:
            if mode == 'target':
                self.aug_target_trainset = SUBCIFAR10(mode, aug, True, 0)
                self.aug_target_train_loader = torch.utils.data.DataLoader(self.aug_target_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.aug_target_testset = SUBCIFAR10(mode, aug, False, 0)
                self.aug_target_test_loader = torch.utils.data.DataLoader(self.aug_target_testset, batch_size=batch_size, shuffle=True, num_workers=2)
            elif mode == 'shadow':
                self.aug_shadow_trainset = SUBCIFAR10(mode, aug, True)
                self.aug_shadow_train_loader = torch.utils.data.DataLoader(self.aug_shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.aug_shadow_testset = SUBCIFAR10(mode, aug, False)
                self.aug_shadow_test_loader = torch.utils.data.DataLoader(self.aug_shadow_testset, batch_size=batch_size, shuffle=True, num_workers=2)
            elif 'distill' in mode:
                self.aug_distill_trainset = SUBCIFAR10(mode, aug, True, 1)
                self.aug_distill_train_loader = torch.utils.data.DataLoader(self.aug_distill_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.aug_distill_testset = SUBCIFAR10(mode, aug, False, 0)
                self.aug_distill_test_loader = torch.utils.data.DataLoader(self.aug_distill_testset, batch_size=batch_size, shuffle=True, num_workers=2)

        else: #aug = False
            if mode == 'target':
                self.target_trainset = SUBCIFAR10(mode, aug, True, type=0) #加载target model的训练集
                self.target_train_loader = torch.utils.data.DataLoader(self.target_trainset, batch_size=batch_size, shuffle=False, num_workers=0)


                self.target_testset = SUBCIFAR10(mode, aug, False, type=0) #加载target model的测试集
                self.target_test_loader = torch.utils.data.DataLoader(self.target_testset, batch_size=batch_size, shuffle=False, num_workers=0)

                self.shadow_trainset = SUBCIFAR10('shadow', aug, True, type=0)
                self.shadow_train_loader = torch.utils.data.DataLoader(self.shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.shadow_testset = SUBCIFAR10('shadow', aug, False, type=0)
                self.shadow_test_loader = torch.utils.data.DataLoader(self.shadow_testset, batch_size=batch_size, shuffle=True, num_workers=2)



                self.target_trainset_aug1 = SUBCIFAR10(mode, True, True, type=1)  # Pad
                self.target_train_aug_loader1 = torch.utils.data.DataLoader(self.target_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)
                self.target_trainset_aug2 = SUBCIFAR10(mode, True, True, type=2)  # Horizontal_Flip
                self.target_train_aug_loader2 = torch.utils.data.DataLoader(self.target_trainset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.target_trainset_aug3 = SUBCIFAR10(mode, True, True, type=3)  # 数据增强：Crop
                self.target_train_aug_loader3 = torch.utils.data.DataLoader(self.target_trainset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_trainset_aug4 = SUBCIFAR10(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_train_aug_loader4 = torch.utils.data.DataLoader(self.target_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.target_trainset_aug5 = SUBCIFAR10(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_train_aug_loader5 = torch.utils.data.DataLoader(self.target_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.target_trainset_aug6 = SUBCIFAR10(mode, True, True, type=6)  # 数据增强：ColorJitter
                self.target_train_aug_loader6 = torch.utils.data.DataLoader(self.target_trainset_aug6,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug7 = SUBCIFAR10(mode, True, True, type=7)  # 数据增强：ColorJitter
                self.target_train_aug_loader7 = torch.utils.data.DataLoader(self.target_trainset_aug7,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_trainset_aug8 = SUBCIFAR10(mode, True, True, type=8)  # RandomResizedCrop
                self.target_train_aug_loader8 = torch.utils.data.DataLoader(self.target_trainset_aug8,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_testset_aug1 = SUBCIFAR10(mode, True, False, type=1)  # Pad
                self.target_test_aug_loader1 = torch.utils.data.DataLoader(self.target_testset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.target_testset_aug2 = SUBCIFAR10(mode, True, False,type=2) # 数据增强：Horizontal_Flip
                self.target_test_aug_loader2 = torch.utils.data.DataLoader(self.target_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.target_testset_aug3 = SUBCIFAR10(mode, True, False, type=3)  # 数据增强：Crop
                self.target_test_aug_loader3 = torch.utils.data.DataLoader(self.target_testset_aug3,
                                                                          batch_size=batch_size, shuffle=False,
                                                                          num_workers=2)

                self.target_testset_aug4 = SUBCIFAR10(mode, True, False, type=4)  # 数据增强：Vertical_Flip
                self.target_test_aug_loader4 = torch.utils.data.DataLoader(self.target_testset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.target_testset_aug5 = SUBCIFAR10(mode, True, False, type=5)  # 数据增强：ColorJitter
                self.target_test_aug_loader5 = torch.utils.data.DataLoader(self.target_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug6 = SUBCIFAR10(mode, True, False, type=6)  # 数据增强：Rotation
                self.target_test_aug_loader6 = torch.utils.data.DataLoader(self.target_testset_aug6,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.target_testset_aug7 = SUBCIFAR10(mode, True, False, type=7)  # 数据增强：Affine
                self.target_test_aug_loader7 = torch.utils.data.DataLoader(self.target_testset_aug7,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)



            elif mode == 'shadow':
                self.shadow_trainset = SUBCIFAR10(mode, aug, True, type=0)
                self.shadow_train_loader = torch.utils.data.DataLoader(self.shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=2)
                self.shadow_testset = SUBCIFAR10(mode, aug, False, type=0)
                self.shadow_test_loader = torch.utils.data.DataLoader(self.shadow_testset, batch_size=batch_size, shuffle=True, num_workers=2)

                self.shadow_trainset_aug1 = SUBCIFAR10(mode, True, True, type=1)  # Pad
                self.shadow_train_aug_loader1 = torch.utils.data.DataLoader(self.shadow_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)
                self.shadow_trainset_aug2 = SUBCIFAR10(mode, True, True, type=2)  # Horizontal_Flip
                self.shadow_train_aug_loader2 = torch.utils.data.DataLoader(self.shadow_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug3 = SUBCIFAR10(mode, True, True, type=3)  # 数据增强：Crop
                self.shadow_train_aug_loader3 = torch.utils.data.DataLoader(self.shadow_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_trainset_aug4 = SUBCIFAR10(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.shadow_train_aug_loader4 = torch.utils.data.DataLoader(self.shadow_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug5 = SUBCIFAR10(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.shadow_train_aug_loader5 = torch.utils.data.DataLoader(self.shadow_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_testset_aug1 = SUBCIFAR10(mode, True, False, type=1)  # Pad
                self.shadow_test_aug_loader1 = torch.utils.data.DataLoader(self.shadow_testset_aug1,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug2 = SUBCIFAR10(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.shadow_test_aug_loader2 = torch.utils.data.DataLoader(self.shadow_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug3 = SUBCIFAR10(mode, True, False, type=3)  # 数据增强：Crop
                self.shadow_test_aug_loader3 = torch.utils.data.DataLoader(self.shadow_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug4 = SUBCIFAR10(mode, True, False, type=4)  # 数据增强：Vertical_Flip
                self.shadow_test_aug_loader4 = torch.utils.data.DataLoader(self.shadow_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug5 = SUBCIFAR10(mode, True, False, type=5)  # 数据增强：ColorJitter
                self.shadow_test_aug_loader5 = torch.utils.data.DataLoader(self.shadow_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

            elif 'distill' in mode:
                self.distill_trainset = SUBCIFAR10(mode, aug, True, 0)
                self.distill_train_loader = torch.utils.data.DataLoader(self.distill_trainset, batch_size=batch_size, shuffle=False, num_workers=2)
                self.distill_testset = SUBCIFAR10(mode, aug, False, 0)
                self.distill_test_loader = torch.utils.data.DataLoader(self.distill_testset, batch_size=batch_size, shuffle=False, num_workers=2)
            
class SUBCIFAR100(data.Dataset):
    def __init__(self, mode, aug, train, type):
        self.img_size = 32
        self.num_classes = 100
        self.num_test = 10000
        self.num_train = 50000
        self.mean=[0.507, 0.487, 0.441]
        self.std=[0.267, 0.256, 0.276]
        normalize = transforms.Normalize(mean=self.mean, std=self.std)

        if type == 0:
            self.normalized = transforms.Compose([transforms.ToTensor(), normalize])
            self.augmented = self.normalized
        elif type == 1:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(), transforms.RandomCrop(32, padding=4), transforms.ToTensor(),
                 normalize])
        elif type == 2:
            self.augmented = transforms.Compose(
                [transforms.RandomHorizontalFlip(p=1),  transforms.ToTensor(),
                 normalize])
        elif type == 3:
            self.augmented = transforms.Compose(
                [transforms.RandomCrop(32, padding=4),  transforms.ToTensor(),
                 normalize])
        elif type == 4:
            self.augmented = transforms.Compose(
                [transforms.RandomVerticalFlip(p=0.5)  , transforms.ToTensor(),
                 normalize])
        elif type == 5:
            self.augmented = transforms.Compose(
                [transforms.ColorJitter(brightness=1), transforms.ToTensor(),
                 normalize])


        #self.augmented = transforms.Compose([transforms.RandomHorizontalFlip(), transforms.RandomCrop(32, padding=4),transforms.ToTensor(), normalize])
        self.normalized = transforms.Compose([transforms.ToTensor(), normalize])

        self.aug_trainset =  datasets.CIFAR100(root='/home/c01yili/datasets/common_dataset', train=True, download=True, transform=self.augmented)
        self.aug_testset =  datasets.CIFAR100(root='/home/c01yili/datasets/common_dataset', train=False, download=True, transform=self.augmented)
        self.trainset =  datasets.CIFAR100(root='/home/c01yili/datasets/common_dataset', train=True, download=True, transform=self.normalized)
        self.testset =  datasets.CIFAR100(root='/home/c01yili/datasets/common_dataset', train=False, download=True, transform=self.normalized)

        self.aug_dataset = ConcatDataset([self.aug_trainset, self.aug_testset])
        self.dataset = ConcatDataset([self.trainset, self.testset])
        
        self.aug_target_trainset, self.aug_target_testset, self.aug_shadow_trainset, self.aug_shadow_testset, self.aug_distill_trainset = dataset_split(self.aug_dataset, [10000, 10000, 20000, 10000, 10000])
        self.aug_distill_testset = self.aug_shadow_testset
        self.target_trainset, self.target_testset, self.shadow_trainset, self.shadow_testset, self.distill_trainset = dataset_split(self.dataset, [10000, 10000, 20000, 10000, 10000])
        self.distill_testset = self.shadow_testset

        if mode == 'target':
            if aug:
                if train:
                    self.dataset = self.aug_target_trainset
                else:
                    self.dataset = self.aug_target_testset
            else:
                if train:
                    self.dataset = self.target_trainset
                else:
                    self.dataset = self.target_testset
        elif mode == 'shadow':
            if aug:
                if train:
                    self.dataset = self.aug_shadow_trainset
                else:
                    self.dataset = self.aug_shadow_testset
            else:
                if train:
                    self.dataset = self.shadow_trainset
                else:
                    self.dataset = self.shadow_testset
        elif 'distill' in mode:
            if aug:
                if train:
                    self.dataset = self.aug_distill_trainset
                else:
                    self.dataset = self.aug_distill_testset
            else:
                if train:
                    self.dataset = self.distill_trainset
                else:
                    self.dataset = self.distill_testset

        self.index = range(int(len(self.dataset)))

    def __getitem__(self, idx):
        return self.dataset[idx][0], self.dataset[idx][1], self.index[idx]

    def __len__(self):
        return len(self.index)

class CIFAR100:
    def __init__(self, mode, aug, batch_size=128):
        self.batch_size = batch_size
        self.img_size = 32
        self.num_classes = 100

        if aug:
            if mode == 'target':
                self.aug_target_trainset = SUBCIFAR100(mode, aug, True)
                self.aug_target_train_loader = torch.utils.data.DataLoader(self.aug_target_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.aug_target_testset = SUBCIFAR100(mode, aug, False)
                self.aug_target_test_loader = torch.utils.data.DataLoader(self.aug_target_testset, batch_size=batch_size, shuffle=True, num_workers=1)
            elif mode == 'shadow':
                self.aug_shadow_trainset = SUBCIFAR100(mode, aug, True)
                self.aug_shadow_train_loader = torch.utils.data.DataLoader(self.aug_shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.aug_shadow_testset = SUBCIFAR100(mode, aug, False)
                self.aug_shadow_test_loader = torch.utils.data.DataLoader(self.aug_shadow_testset, batch_size=batch_size, shuffle=True, num_workers=1)
            elif 'distill' in mode:
                self.aug_distill_trainset = SUBCIFAR100(mode, aug, True)
                self.aug_distill_train_loader = torch.utils.data.DataLoader(self.aug_distill_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.aug_distill_testset = SUBCIFAR100(mode, aug, False)
                self.aug_distill_test_loader = torch.utils.data.DataLoader(self.aug_distill_testset, batch_size=batch_size, shuffle=True, num_workers=1)

        else:
            if mode == 'target':
                self.target_trainset = SUBCIFAR100(mode, aug, True, 0)
                self.target_train_loader = torch.utils.data.DataLoader(self.target_trainset, batch_size=batch_size, shuffle=False, num_workers=1)

                self.target_testset = SUBCIFAR100(mode, aug, False, 0)
                self.target_test_loader = torch.utils.data.DataLoader(self.target_testset, batch_size=batch_size, shuffle=False, num_workers=1)

                self.target_trainset_aug1 = SUBCIFAR100(mode, True, True, type=1)
                self.target_train_aug_loader1 = torch.utils.data.DataLoader(self.target_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug2 = SUBCIFAR100(mode, True, True, type=2)  # Horizontal_Flip
                self.target_train_aug_loader2 = torch.utils.data.DataLoader(self.target_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug3 = SUBCIFAR100(mode, True, True, type=3)  # 数据增强：Crop
                self.target_train_aug_loader3 = torch.utils.data.DataLoader(self.target_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug4 = SUBCIFAR100(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_train_aug_loader4 = torch.utils.data.DataLoader(self.target_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_trainset_aug5 = SUBCIFAR100(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_train_aug_loader5 = torch.utils.data.DataLoader(self.target_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=1)

                self.target_testset_aug1 = SUBCIFAR100(mode, True, False, type=1)  # 数据增强：Horizontal_Flip
                self.target_test_aug_loader1 = torch.utils.data.DataLoader(self.target_testset_aug1,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug2 = SUBCIFAR100(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.target_test_aug_loader2 = torch.utils.data.DataLoader(self.target_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug3 = SUBCIFAR100(mode, True, False, type=3)  # 数据增强：Crop
                self.target_test_aug_loader3 = torch.utils.data.DataLoader(self.target_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug4 = SUBCIFAR100(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.target_test_aug_loader4 = torch.utils.data.DataLoader(self.target_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

                self.target_testset_aug5 = SUBCIFAR100(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.target_test_aug_loader5 = torch.utils.data.DataLoader(self.target_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=1)

            elif mode == 'shadow':
                self.shadow_trainset = SUBCIFAR100(mode, aug, True, type=0)
                self.shadow_train_loader = torch.utils.data.DataLoader(self.shadow_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.shadow_testset = SUBCIFAR100(mode, aug, False, type=0)
                self.shadow_test_loader = torch.utils.data.DataLoader(self.shadow_testset, batch_size=batch_size, shuffle=True, num_workers=1)

                self.shadow_trainset_aug1 = SUBCIFAR100(mode, True, True, type=1)  # Pad
                self.shadow_train_aug_loader1 = torch.utils.data.DataLoader(self.shadow_trainset_aug1,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)
                self.shadow_trainset_aug2 = SUBCIFAR100(mode, True, True, type=2)  # Horizontal_Flip
                self.shadow_train_aug_loader2 = torch.utils.data.DataLoader(self.shadow_trainset_aug2,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug3 = SUBCIFAR100(mode, True, True, type=3)  # 数据增强：Crop
                self.shadow_train_aug_loader3 = torch.utils.data.DataLoader(self.shadow_trainset_aug3,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_trainset_aug4 = SUBCIFAR100(mode, True, True, type=4)  # 数据增强：Vertical_Flip
                self.shadow_train_aug_loader4 = torch.utils.data.DataLoader(self.shadow_trainset_aug4,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=0)

                self.shadow_trainset_aug5 = SUBCIFAR100(mode, True, True, type=5)  # 数据增强：ColorJitter
                self.shadow_train_aug_loader5 = torch.utils.data.DataLoader(self.shadow_trainset_aug5,
                                                                            batch_size=batch_size, shuffle=False,
                                                                            num_workers=2)

                self.shadow_testset_aug1 = SUBCIFAR100(mode, True, False, type=1)  # Pad
                self.shadow_test_aug_loader1 = torch.utils.data.DataLoader(self.shadow_testset_aug1,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug2 = SUBCIFAR100(mode, True, False, type=2)  # 数据增强：Horizontal_Flip
                self.shadow_test_aug_loader2 = torch.utils.data.DataLoader(self.shadow_testset_aug2,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug3 = SUBCIFAR100(mode, True, False, type=3)  # 数据增强：Crop
                self.shadow_test_aug_loader3 = torch.utils.data.DataLoader(self.shadow_testset_aug3,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

                self.shadow_testset_aug4 = SUBCIFAR100(mode, True, False, type=4)  # 数据增强：Vertical_Flip
                self.shadow_test_aug_loader4 = torch.utils.data.DataLoader(self.shadow_testset_aug4,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=0)

                self.shadow_testset_aug5 = SUBCIFAR100(mode, True, False, type=5)  # 数据增强：ColorJitter
                self.shadow_test_aug_loader5 = torch.utils.data.DataLoader(self.shadow_testset_aug5,
                                                                           batch_size=batch_size, shuffle=False,
                                                                           num_workers=2)

            elif 'distill' in mode:
                self.distill_trainset = SUBCIFAR100(mode, aug, True)
                self.distill_train_loader = torch.utils.data.DataLoader(self.distill_trainset, batch_size=batch_size, shuffle=True, num_workers=1)
                self.distill_testset = SUBCIFAR100(mode, aug, False)
                self.distill_test_loader = torch.utils.data.DataLoader(self.distill_testset, batch_size=batch_size, shuffle=True, num_workers=1)

class AverageMeter(object):
    """Computes and stores the average and current value"""
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

def accuracy(output, target, topk=(1,)):
    """Computes the precision@k for the specified values of k"""
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)
        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
    return res